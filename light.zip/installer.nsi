!include "WordFunc.nsh"

!define APPNAME "Light"
!define VERSION "0.1.0"

Name "${APPNAME}"
OutFile "LightSetup.exe"
InstallDir "$LOCALAPPDATA\Light"
RequestExecutionLevel user

Page directory
Page instfiles
UninstPage instfiles

Var OLDPATH
Var NEWPATH

Section "Install"
    SetOutPath "$INSTDIR\bin"
    File "light.exe"

    SetOutPath "$INSTDIR\examples\flappybird"
    File /r "examples\flappybird\*.*"

    SetOutPath "$INSTDIR\examples\doom"
    File /r "examples\doom\*.*"

    SetOutPath "$INSTDIR\examples\badapple"
    File /r "examples\badapple\*.*"

    SetOutPath "$INSTDIR\examples\3d_demo"
    File /r "examples\3d_demo\*.*"

    SetOutPath "$INSTDIR\examples\video_demo"
    File /r "examples\video_demo\*.*"

    SetOutPath "$INSTDIR"
    WriteUninstaller "$INSTDIR\uninstall.exe"

    ReadRegStr $OLDPATH HKCU "Environment" "Path"
    ${WordFind} "$OLDPATH" ";" "E+$INSTDIR\bin" $NEWPATH
    IfErrors 0 alreadyThere
        StrCpy $NEWPATH "$OLDPATH;$INSTDIR\bin"
        WriteRegExpandStr HKCU "Environment" "Path" "$NEWPATH"
        Goto broadcast
    alreadyThere:
    broadcast:
    System::Call 'user32::SendMessageTimeoutA(i 0xffff, i 0x1A, i 0, t "Environment", i 0, i 5000, i .r0)'

    MessageBox MB_OK "Light installed.$\r$\n$\r$\nOpen a NEW terminal and run:  light yourfile.light$\r$\n$\r$\nTry the demos:$\r$\ncd $INSTDIR\examples\flappybird & light main.light$\r$\ncd $INSTDIR\examples\doom & light main.light$\r$\ncd $INSTDIR\examples\badapple & light main.light$\r$\ncd $INSTDIR\examples\3d_demo & light main.light$\r$\ncd $INSTDIR\examples\video_demo & light main.light"
SectionEnd

Section "Uninstall"
    RMDir /r "$INSTDIR"
    ReadRegStr $OLDPATH HKCU "Environment" "Path"
    ${WordReplace} "$OLDPATH" "$INSTDIR\bin" "" "+" $NEWPATH
    ${WordReplace} "$NEWPATH" ";;" ";" "+" $NEWPATH
    WriteRegExpandStr HKCU "Environment" "Path" "$NEWPATH"
    System::Call 'user32::SendMessageTimeoutA(i 0xffff, i 0x1A, i 0, t "Environment", i 0, i 5000, i .r0)'
SectionEnd
