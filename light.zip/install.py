import os
import sys
import json
import shutil
import winreg
import ctypes
import subprocess
from pathlib import Path

LIGHT_VERSION   = "1.0.0"
INSTALL_DIR     = Path("C:\\Light")
WRAPPER_NAME    = "light.cmd"
VERSION_FILE    = "version.json"
SOURCE_DIR      = Path(__file__).parent / "light"

COLORS = {
    "reset":  "\033[0m",
    "bold":   "\033[1m",
    "blue":   "\033[94m",
    "green":  "\033[92m",
    "yellow": "\033[93m",
    "red":    "\033[91m",
    "cyan":   "\033[96m",
    "gray":   "\033[90m",
}

def c(color, text):
    return COLORS.get(color, "") + str(text) + COLORS["reset"]

def is_admin() -> bool:
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def enable_ansi():
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    except:
        pass

def banner():
    print()
    print(c("cyan", "  ╔══════════════════════════════════════════╗"))
    print(c("cyan", "  ║") + c("bold", "     Light Language Installer v" + LIGHT_VERSION + "     ") + c("cyan", "║"))
    print(c("cyan", "  ╚══════════════════════════════════════════╝"))
    print()

def step(msg: str):
    print(f"  {c('blue', '→')} {msg}")

def ok(msg: str):
    print(f"  {c('green', '✓')} {msg}")

def warn(msg: str):
    print(f"  {c('yellow', '!')} {msg}")

def error(msg: str):
    print(f"  {c('red', '✗')} {msg}")

def ask(prompt: str, default="y") -> str:
    opts = "[Y/n]" if default == "y" else "[y/N]"
    try:
        ans = input(f"  {c('yellow', '?')} {prompt} {opts}: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return default
    return ans if ans in ("s", "y", "n") else default

def get_installed_version() -> str | None:
    vfile = INSTALL_DIR / VERSION_FILE
    if not vfile.exists():
        return None
    try:
        with open(vfile, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("version")
    except:
        return None

def version_tuple(v: str):
    return tuple(int(x) for x in v.split("."))

def get_user_path() -> str:
    key = winreg.OpenKey(
        winreg.HKEY_CURRENT_USER,
        r"Environment",
        0, winreg.KEY_READ
    )
    try:
        value, _ = winreg.QueryValueEx(key, "Path")
        return value
    except FileNotFoundError:
        return ""
    finally:
        winreg.CloseKey(key)

def set_user_path(new_path: str):
    key = winreg.OpenKey(
        winreg.HKEY_CURRENT_USER,
        r"Environment",
        0, winreg.KEY_SET_VALUE
    )
    winreg.SetValueEx(key, "Path", 0, winreg.REG_EXPAND_SZ, new_path)
    winreg.CloseKey(key)
    HWND_BROADCAST = 0xFFFF
    WM_SETTINGCHANGE = 0x001A
    ctypes.windll.user32.SendMessageW(HWND_BROADCAST, WM_SETTINGCHANGE, 0, "Environment")

def add_to_path(directory: str):
    current = get_user_path()
    entries = [e for e in current.split(";") if e.strip()]
    if directory not in entries:
        entries.append(directory)
        set_user_path(";".join(entries))
        ok(f"Added to user PATH: {directory}")
    else:
        ok(f"Already in PATH: {directory}")

def remove_from_path(directory: str):
    current = get_user_path()
    entries = [e for e in current.split(";") if e.strip() and e != directory]
    set_user_path(";".join(entries))
    ok(f"Removed from PATH: {directory}")

def create_wrapper():
    wrapper_path = INSTALL_DIR / WRAPPER_NAME
    python_exe   = sys.executable
    cli_script   = INSTALL_DIR / "light_cli.py"
    content = f"""@echo off
"{python_exe}" "{cli_script}" %*
"""
    with open(wrapper_path, "w", encoding="utf-8") as f:
        f.write(content)
    ok(f"Wrapper created: {wrapper_path}")

FILES_TO_COPY = [
    "light_cli.py",
    "version.json",
    "src/__init__.py",
    "src/lexer.py",
    "src/parser.py",
    "src/ast_nodes.py",
    "src/interpreter.py",
]

def copy_files(source: Path, dest: Path, only_changed=False):
    (dest / "src").mkdir(parents=True, exist_ok=True)
    copied = 0
    skipped = 0
    for rel in FILES_TO_COPY:
        src_file  = source / rel
        dest_file = dest / rel
        if not src_file.exists():
            warn(f"File missing in directory: {rel}")
            continue
        if only_changed and dest_file.exists():
            if src_file.read_bytes() == dest_file.read_bytes():
                skipped += 1
                continue
        dest_file.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_file, dest_file)
        copied += 1
    if copied:
        ok(f"Copied {copied} file{' (updated)' if only_changed else ''}")
    if skipped:
        print(f"  {c('gray', f'  {skipped} same files, skipping...')}")

def update_version_file(dest: Path):
    vfile = dest / VERSION_FILE
    data = {
        "version": LIGHT_VERSION,
        "name": "Light Language",
        "install_dir": str(dest),
        "files": FILES_TO_COPY
    }
    with open(vfile, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def install():
    banner()
    print(f"  Will install {c('bold', 'Light v' + LIGHT_VERSION)} in {c('cyan', str(INSTALL_DIR))}")
    print()
    installed = get_installed_version()
    is_update = False
    if installed:
        if version_tuple(installed) == version_tuple(LIGHT_VERSION):
            warn(f"Light v{installed} is already installed.")
            ans = ask("Would you like to reinstall / repair the installation?")
            if ans == "n":
                print()
                print("  Cancelled.")
                return
        elif version_tuple(installed) < version_tuple(LIGHT_VERSION):
            print(f"  {c('yellow', f'Installed version: v{installed}')} → {c('green', f'New version: v{LIGHT_VERSION}')}")
            ans = ask("Would you like to install Light?")
            if ans == "n":
                print()
                print("  Update dismissed.")
                return
            is_update = True
        else:
            warn(f"A newer version is already installed: (v{installed}).")
            ans = ask("Would you still like to install v" + LIGHT_VERSION + " (downgrade)?")
            if ans == "n":
                return
    step("Checking for Python...")
    pv = sys.version_info
    if pv < (3, 10):
        error(f"Python 3.10+ needed, found {pv.major}.{pv.minor}")
        sys.exit(1)
    ok(f"Python {pv.major}.{pv.minor}.{pv.micro} found")
    step("File verification...")
    if not SOURCE_DIR.exists():
        error(f"Source folder not found: {SOURCE_DIR}")
        error("Make sure the 'light/' folder is next to the installer.")
        sys.exit(1)
    ok(f"Source found: {SOURCE_DIR}")
    step(f"Preparing folder {INSTALL_DIR}...")
    if is_update and INSTALL_DIR.exists():
        step("Removing old files...")
        for rel in FILES_TO_COPY:
            old = INSTALL_DIR / rel
            if old.exists():
                old.unlink()
        old_wrapper = INSTALL_DIR / WRAPPER_NAME
        if old_wrapper.exists():
            old_wrapper.unlink()
        ok("Old files removed")
    else:
        INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    ok(f"Folder ready")
    step("Copying Light files...")
    copy_files(SOURCE_DIR, INSTALL_DIR, only_changed=is_update)
    update_version_file(INSTALL_DIR)
    ok(f"version.json updated to v{LIGHT_VERSION}")
    step("Creating 'light' command...")
    create_wrapper()
    step("Updating system PATH...")
    add_to_path(str(INSTALL_DIR))
    print()
    print(c("green", "  ══════════════════════════════════════════"))
    if is_update:
        print(c("green", f"  ✓  Light successfully updated to v{LIGHT_VERSION}!"))
    else:
        print(c("green", f"  ✓  Light v{LIGHT_VERSION} successfully installed!"))
    print(c("green", "  ══════════════════════════════════════════"))
    print()
    print(f"  {c('bold', 'Reopen CMD')} and run:")
    print(f"    {c('cyan', 'light')}                    → info and version")
    print(f"    {c('cyan', 'light script.light')}       → execute a file")
    print(f"    {c('cyan', 'light --version')}          → show version")
    print()

def uninstall():
    banner()
    installed = get_installed_version()
    if not installed and not INSTALL_DIR.exists():
        warn("Light does not seem to be installed.")
        return
    ver_str = f"v{installed}" if installed else "(unknown version)"
    print(f"  This will remove {c('bold', f'Light {ver_str}')} from {c('cyan', str(INSTALL_DIR))}")
    print()
    ans = ask("Are you sure you want to uninstall Light?", default="n")
    if ans == "n":
        print("\n  Uninstallation canceled.")
        return
    step("Removing from PATH...")
    try:
        remove_from_path(str(INSTALL_DIR))
    except Exception as e:
        warn(f"Could not remove from PATH: {e}")
    step(f"Removing folder {INSTALL_DIR}...")
    try:
        shutil.rmtree(INSTALL_DIR)
        ok("Folder removed")
    except Exception as e:
        error(f"Could not remove folder: {e}")
        error("Try running the installer as administrator.")
        sys.exit(1)
    print()
    print(c("green", "  ✓  Light successfully uninstalled."))
    print(f"  {c('gray', 'Reopen CMD to apply changes.')}")
    print()

def main():
    enable_ansi()
    if not is_admin():
        warn("You are not running as administrator.")
        warn("If the PATH does not update, rerun as administrator.")
        print()
    if len(sys.argv) > 1 and sys.argv[1] == "uninstall":
        uninstall()
    else:
        install()

if __name__ == "__main__":
    main()