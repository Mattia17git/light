@echo off
chcp 65001 >nul
title Light Language Installer

:: checks if python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [ERROR] Python not found!
    echo  download python from https://www.python.org/downloads/
    echo  Make sure to check "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

:: Exec python installer
python "%~dp0install.py" %*

pause
