# Light Tutorial

This guide takes you from zero to the most advanced features of the language: variables, functions, tables, and then the 2D/3D engine, audio, and video. Every example is commented (in Light, comments start with `--`).

To run any script from this guide: save it as `filename.light` and run from a terminal:

```
light filename.light
```

---

## 1. The basics

### Variables

```lua
-- "local" creates a variable visible only in the current block
local age = 25
local name = "Marco"
local active = true
local nothing = nil -- "nil" represents the absence of a value

print(name, age, active)
```

### Numbers, strings, and concatenation

```lua
local a = 10
local b = 3

print(a + b)   -- addition: 13
print(a - b)   -- subtraction: 7
print(a * b)   -- multiplication: 30
print(a / b)   -- division: 3.333...
print(a % b)   -- remainder: 1
print(a ^ b)   -- power: 1000

-- ".." joins strings together (concatenation)
local greeting = "Hi " .. name .. ", you are " .. tostring(age) .. " years old"
print(greeting)
```

`tostring()` converts a number (or other value) into a string. `tonumber()` does the opposite.

### Comparisons and boolean values

```lua
print(5 > 3)      -- true
print(5 == 5)      -- true
print(5 ~= 3)      -- true ("~=" means "not equal to")
print(not true)    -- false
print(true and false)  -- false
print(true or false)   -- true
```

---

## 2. Control flow

### if / elseif / else

```lua
local grade = 7

if grade >= 9 then
    print("excellent")
elseif grade >= 6 then
    print("passing")
else
    print("needs improvement")
end
```

### while

```lua
local i = 0
while i < 5 do
    print("iteration", i)
    i = i + 1
end
```

### numeric for

```lua
-- for VAR = start, stop, step do ... end
-- the step is optional (default 1)
for i = 1, 5 do
    print(i)
end

for i = 10, 0, -2 do  -- from 10 down to 0, in steps of 2
    print(i)
end
```

### for over a table (for-in)

```lua
local fruits = {"apple", "pear", "banana"}

for index, value in fruits do
    print(index, value)
end
```

### break and return

```lua
for i = 1, 100 do
    if i > 3 then
        break -- exits the loop right away
    end
    print(i)
end
```

`return` exits a function, optionally handing back a value (see section 3).

---

## 3. Functions

```lua
local function add(a, b)
    return a + b
end

print(add(4, 5)) -- 9
```

Functions are values just like anything else: you can store them in variables, pass them as arguments, or create them "on the fly":

```lua
local multiply = function(a, b)
    return a * b
end

print(multiply(3, 4)) -- 12
```

### Closures (functions that "remember" outer variables)

```lua
local function makeCounter()
    local count = 0
    local function increment()
        count = count + 1
        return count
    end
    return increment
end

local counter = makeCounter()
print(counter()) -- 1
print(counter()) -- 2
print(counter()) -- 3
```

---

## 4. Tables

Tables are Light's only "compound" data structure: you can use them as lists (arrays) or as dictionaries (key/value maps).

```lua
-- as a list
local numbers = {10, 20, 30}
print(numbers[1]) -- 10 (indexes start at 1, not 0)

-- as a dictionary
local person = {}
person.name = "Anna"
person["age"] = 30 -- person.age and person["age"] are equivalent

print(person.name, person.age)

-- direct creation mixing both styles
local player = {
    name = "Luigi",
    health = 100,
    inventory = {"sword", "shield"}
}
print(player.name, player.inventory[1])
```

### Functions inside tables (kind of like "methods")

```lua
local rectangle = {}
rectangle.width = 4
rectangle.height = 3

function rectangle.area(r)
    return r.width * r.height
end

print(rectangle.area(rectangle)) -- 12
```

---

## 5. Math library

```lua
print(math.floor(4.7))   -- 4  (rounds down)
print(math.ceil(4.2))    -- 5  (rounds up)
print(math.abs(-9))      -- 9  (absolute value)
print(math.sqrt(16))     -- 4  (square root)
print(math.sin(0))       -- sine
print(math.cos(0))       -- cosine
print(math.max(3, 8, 1)) -- 8
print(math.min(3, 8, 1)) -- 1
print(math.pi)           -- 3.14159...

print(math.random())        -- a decimal number between 0 and 1
print(math.random(10))      -- an integer between 1 and 10
print(math.random(5, 15))   -- an integer between 5 and 15
```

Other useful global functions: `type(value)` returns the type ("number", "string", "table", etc.), `len(value)` returns the length of a string or the number of items in a list-like table.

---

## 6. Opening a window and drawing in 2D

This is where the "game engine" part of Light starts. Every graphical program follows this shape:

```lua
-- 1. open the window once, at the start
window.open(800, 600, "My game")

-- 2. the game loop: repeats until you close the window
while not window.shouldClose() do
    draw.begin()             -- start drawing this frame
    draw.clear(30, 30, 40)   -- clear the screen with a color (r, g, b)

    draw.rect(100, 100, 50, 50, 255, 0, 0)       -- red rectangle
    draw.circle(400, 300, 40, 0, 200, 255)       -- light-blue circle
    draw.line(0, 0, 800, 600, 255, 255, 255)     -- white line
    draw.text("Hello Light!", 10, 10, 24, 255, 255, 255) -- text

    draw.finish()            -- present the frame you just drew
end

window.close() -- close the window at the end
```

Functions available under `draw`:

```lua
draw.begin()                              -- start of frame
draw.finish()                             -- end of frame (shows it on screen)
draw.clear(r, g, b)                       -- background
draw.rect(x, y, width, height, r, g, b)
draw.circle(x, y, radius, r, g, b)
draw.line(x1, y1, x2, y2, r, g, b)
draw.text(text, x, y, size, r, g, b)
draw.fps(x, y)                            -- shows the FPS counter
draw.screenshot(path)                     -- saves the current frame as a PNG
```

Colors range from 0 to 255 (the usual red/green/blue graphics convention).

---

## 7. Images

```lua
window.open(800, 600, "Images")

local sprite = image.load("assets/character.png") -- returns a handle (a number)

while not window.shouldClose() do
    draw.begin()
    draw.clear(0, 0, 0)
    image.draw(sprite, 100, 100)         -- draws it at (100,100), scale 1
    image.draw(sprite, 300, 100, 2.0)    -- same image, scaled up 2x
    draw.finish()
end

window.close()
```

`image.width(handle)` and `image.height(handle)` return the image's original dimensions.

---

## 8. Keyboard and mouse input

```lua
window.open(800, 600, "Input")
local x = 400
local y = 300

while not window.shouldClose() do
    local dt = time.dt() -- seconds elapsed since the last frame

    -- input.key: true for as long as the key is held down
    if input.key("left") then x = x - 200 * dt end
    if input.key("right") then x = x + 200 * dt end
    if input.key("up") then y = y - 200 * dt end
    if input.key("down") then y = y + 200 * dt end

    -- input.keyPressed: true only on the frame the key was first pressed
    if input.keyPressed("space") then
        print("SPACE pressed once")
    end

    draw.begin()
    draw.clear(20, 20, 20)
    draw.circle(x, y, 20, 255, 200, 0)

    if input.mouseDown() then
        draw.circle(input.mouseX(), input.mouseY(), 10, 255, 0, 0)
    end

    draw.finish()
end
window.close()
```

Keys recognized by `input.key` / `input.keyPressed`: single letters (`"a"`-`"z"`), digits (`"0"`-`"9"`), and the special names `"space"`, `"up"`, `"down"`, `"left"`, `"right"`, `"enter"`, `"escape"`.

`time.dt()` is essential for movement: it returns how much time (in seconds) passed since the previous frame, so movement stays smooth regardless of framerate. `time.now()` returns the seconds elapsed since the window was opened.

---

## 9. Audio

```lua
window.open(400, 300, "Audio")

local jump = audio.loadSound("assets/jump.wav")   -- short sound effect
local music = audio.loadMusic("assets/theme.wav")  -- streamed music

audio.playMusic(music)

while not window.shouldClose() do
    audio.updateMusic(music) -- must be called every frame to keep the music playing

    if input.keyPressed("space") then
        audio.play(jump) -- plays the sound effect
    end

    draw.begin()
    draw.clear(10, 10, 10)
    draw.finish()
end
window.close()
```

Use `loadSound`/`play` for short effects (jumps, hits, scoring) and `loadMusic`/`playMusic`/`updateMusic` for long, looping tracks.

---

## 10. Video

Light ships its own homemade video format called `.lvid`, designed for simple content (it is not a codec for real-world, highly detailed video). You create one with the Python script included under `tools/`.

```lua
window.open(640, 480, "Video")

local clip = video.load("assets/clip.lvid")
video.setLoop(clip, true) -- true = loops forever, false = stops at the end
video.play(clip)

while not window.shouldClose() do
    video.update(clip, time.dt()) -- advances the video by a frame when needed

    draw.begin()
    draw.clear(0, 0, 0)
    video.draw(clip, 0, 0, 640, 480)
    draw.finish()
end
window.close()
```

Other commands: `video.pause(clip)`, `video.stop(clip)` (pauses and rewinds to the start), `video.seek(clip, seconds)`, `video.isFinished(clip)` (useful when `setLoop` is `false`), `video.duration(clip)` (total length in seconds).

To create your own `.lvid` file from a real video (mp4, mov...), use `tools/mp4_to_lvid.py` (requires `ffmpeg` installed):

```
python3 tools/mp4_to_lvid.py video.mp4 clip.lvid --fps 12 --width 320
```

---

## 11. 3D rendering

The `d3` module draws in 3D inside the same 2D window: you open a "3D block" with `d3.begin()`/`d3.finish()`, and anything you draw outside that block stays regular 2D (handy for score, menus, etc. drawn on top of the 3D scene).

```lua
window.open(800, 600, "3D World")

-- position the camera: (xyz position, xyz look-at point, field of view)
d3.camera(10, 8, 10,   0, 0, 0,   45)

while not window.shouldClose() do
    draw.begin()
    draw.clear(140, 190, 230)

    d3.begin()
    d3.grid(20, 1.0)                              -- gridded ground plane
    d3.cube(0, 1, 0, 2, 2, 2, 200, 60, 60)        -- solid cube
    d3.cubeWires(0, 1, 0, 2, 2, 2, 20, 20, 20)    -- cube outline
    d3.sphere(4, 1, 0, 1, 60, 160, 220)           -- sphere
    d3.line(0, 0, 0, 4, 1, 0, 0, 0, 0)             -- a line in 3D space
    d3.finish()

    draw.text("Score: 0", 10, 10, 20, 255, 255, 255) -- 2D HUD on top of the 3D scene
    draw.finish()
end
window.close()
```

To move the camera during gameplay, call `d3.setPos(x, y, z)` and `d3.setTarget(x, y, z)` every frame:

```lua
local angle = 0

while not window.shouldClose() do
    angle = angle + time.dt()
    local camX = math.cos(angle) * 10
    local camZ = math.sin(angle) * 10
    d3.setPos(camX, 8, camZ)   -- the camera orbits around the center
    d3.setTarget(0, 0, 0)
    -- ... rest of the drawing
end
```

---

## 12. Putting it all together: the shape of a real game

This is the typical skeleton you'll find in the examples under `examples/` (flappybird, doom, 3d_demo...):

```lua
-- 1. constants and settings
local WIDTH = 640
local HEIGHT = 480

-- 2. open the window and load assets (only once)
window.open(WIDTH, HEIGHT, "My game")
local jumpSound = audio.loadSound("assets/jump.wav")

-- 3. game state (variables that change over time)
local playerX = WIDTH / 2
local playerY = HEIGHT / 2
local score = 0

-- 4. main loop
while not window.shouldClose() do
    local dt = time.dt()

    -- 4a. handle input and update state
    if input.key("left") then playerX = playerX - 200 * dt end
    if input.key("right") then playerX = playerX + 200 * dt end

    -- 4b. draw
    draw.begin()
    draw.clear(20, 20, 30)
    draw.circle(playerX, playerY, 20, 255, 200, 0)
    draw.text("Score: " .. tostring(score), 10, 10, 20, 255, 255, 255)
    draw.finish()
end

-- 5. shutdown
window.close()
```

From here, check out the examples under `examples/` to see these ideas applied to a full game: collisions (`flappybird`), a pseudo-3D engine made of plain rectangles (`doom`), real 3D rendering with an orbiting camera (`3d_demo`), and video playback (`video_demo`).

---

## Quick reference for every function

This section is a reference listing only (using `v`, `...` etc. as placeholders) — it isn't meant to be run as-is.

```lua
-- basics
print(...)
tostring(v)
tonumber(v)
type(v)
len(v)

-- math
math.random([a[, b]])
math.floor(n)  math.ceil(n)  math.abs(n)  math.sqrt(n)
math.sin(n)    math.cos(n)
math.max(...)  math.min(...)
math.pi

-- window
window.open(width, height, title)
window.shouldClose()
window.close()
window.setTitle(title)

-- 2D drawing
draw.begin()  draw.finish()
draw.clear(r, g, b)
draw.rect(x, y, w, h, r, g, b)
draw.circle(x, y, radius, r, g, b)
draw.line(x1, y1, x2, y2, r, g, b)
draw.text(text, x, y, size, r, g, b)
draw.fps(x, y)
draw.screenshot(path)

-- images
image.load(path)
image.draw(handle, x, y[, scale])
image.width(handle)  image.height(handle)

-- input
input.key(name)  input.keyPressed(name)
input.mouseDown()  input.mouseX()  input.mouseY()

-- audio
audio.loadSound(path)  audio.play(handle)
audio.loadMusic(path)  audio.playMusic(handle)  audio.updateMusic(handle)

-- video
video.load(path)
video.play(handle)  video.pause(handle)  video.stop(handle)
video.update(handle, dt)
video.draw(handle, x, y[, w, h])
video.seek(handle, seconds)
video.isFinished(handle)
video.setLoop(handle, true/false)
video.duration(handle)

-- 3D
d3.camera(x, y, z, targetX, targetY, targetZ[, fovy])
d3.setPos(x, y, z)  d3.setTarget(x, y, z)
d3.begin()  d3.finish()
d3.cube(x, y, z, w, h, d, r, g, b)
d3.cubeWires(x, y, z, w, h, d, r, g, b)
d3.sphere(x, y, z, radius, r, g, b)
d3.plane(x, y, z, w, d, r, g, b)
d3.line(x1, y1, z1, x2, y2, z2, r, g, b)
d3.grid(slices, spacing)

-- time
time.dt()   -- seconds since the last frame
time.now()  -- seconds since window.open
```
