#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <stdarg.h>
#ifdef _WIN32
#include <direct.h>
#define chdir _chdir
#else
#include <unistd.h>
#endif

#ifndef LIGHT_VERSION
#define LIGHT_VERSION "0.1.0"
#endif

#ifdef LIGHT_GRAPHICS
#include "raylib.h"
#endif

static void *xmalloc(size_t n){ void *p=malloc(n); if(!p){fprintf(stderr,"out of memory\n"); exit(1);} return p; }
static void *xrealloc(void *o,size_t n){ void *p=realloc(o,n); if(!p){fprintf(stderr,"out of memory\n"); exit(1);} return p; }
static char *xstrdup(const char *s){ size_t n=strlen(s)+1; char *p=xmalloc(n); memcpy(p,s,n); return p; }

typedef enum {
    T_EOF, T_NUMBER, T_STRING, T_NAME,
    T_PLUS, T_MINUS, T_STAR, T_SLASH, T_PERCENT, T_CARET,
    T_EQ, T_EQEQ, T_NEQ, T_LT, T_LE, T_GT, T_GE,
    T_LPAREN, T_RPAREN, T_LBRACE, T_RBRACE, T_LBRACKET, T_RBRACKET,
    T_COMMA, T_DOT, T_DOTDOT, T_COLON, T_SEMI,
    T_LOCAL, T_FUNCTION, T_IF, T_THEN, T_ELSE, T_ELSEIF, T_END,
    T_WHILE, T_DO, T_FOR, T_IN, T_RETURN, T_BREAK, T_TRUE, T_FALSE, T_NIL,
    T_AND, T_OR, T_NOT
} TokType;

typedef struct {
    TokType type;
    char *text;
    double num;
    int line;
} Token;

typedef struct {
    const char *src;
    int pos;
    int line;
    Token cur;
    Token ahead;
    int has_ahead;
} Lexer;

static struct { const char *word; TokType type; } keywords[] = {
    {"local",T_LOCAL},{"function",T_FUNCTION},{"if",T_IF},{"then",T_THEN},
    {"else",T_ELSE},{"elseif",T_ELSEIF},{"end",T_END},{"while",T_WHILE},
    {"do",T_DO},{"for",T_FOR},{"in",T_IN},{"return",T_RETURN},{"break",T_BREAK},
    {"true",T_TRUE},{"false",T_FALSE},{"nil",T_NIL},{"and",T_AND},{"or",T_OR},
    {"not",T_NOT}, {NULL,0}
};

static void lexer_init(Lexer *lx, const char *src){
    lx->src=src; lx->pos=0; lx->line=1; lx->has_ahead=0;
}

static int lx_peekc(Lexer *lx){ return lx->src[lx->pos]; }
static int lx_peekc2(Lexer *lx){ return lx->src[lx->pos] ? lx->src[lx->pos+1] : 0; }
static int lx_advc(Lexer *lx){ int c = lx->src[lx->pos]; if(c){ lx->pos++; if(c=='\n') lx->line++; } return c; }

static void skip_ws(Lexer *lx){
    for(;;){
        int c = lx_peekc(lx);
        if(c==' '||c=='\t'||c=='\r'||c=='\n'){ lx_advc(lx); continue; }
        if(c=='-' && lx_peekc2(lx)=='-'){
            while(lx_peekc(lx) && lx_peekc(lx)!='\n') lx_advc(lx);
            continue;
        }
        break;
    }
}

static Token lex_next_raw(Lexer *lx){
    skip_ws(lx);
    Token t; t.text=NULL; t.num=0; t.line=lx->line;
    int c = lx_peekc(lx);
    if(!c){ t.type=T_EOF; return t; }
    if(isdigit(c) || (c=='.' && isdigit(lx_peekc2(lx)))){
        int start=lx->pos;
        while(isdigit(lx_peekc(lx))) lx_advc(lx);
        if(lx_peekc(lx)=='.'){ lx_advc(lx); while(isdigit(lx_peekc(lx))) lx_advc(lx); }
        if(lx_peekc(lx)=='e'||lx_peekc(lx)=='E'){ lx_advc(lx); if(lx_peekc(lx)=='+'||lx_peekc(lx)=='-') lx_advc(lx); while(isdigit(lx_peekc(lx))) lx_advc(lx); }
        int len = lx->pos-start;
        char *buf = xmalloc(len+1); memcpy(buf,lx->src+start,len); buf[len]=0;
        t.type=T_NUMBER; t.num=atof(buf); free(buf);
        return t;
    }
    if(isalpha(c) || c=='_'){
        int start=lx->pos;
        while(isalnum(lx_peekc(lx)) || lx_peekc(lx)=='_') lx_advc(lx);
        int len = lx->pos-start;
        char *buf = xmalloc(len+1); memcpy(buf,lx->src+start,len); buf[len]=0;
        for(int i=0; keywords[i].word; i++){
            if(strcmp(keywords[i].word,buf)==0){ t.type=keywords[i].type; free(buf); return t; }
        }
        t.type=T_NAME; t.text=buf;
        return t;
    }
    if(c=='"' || c=='\''){
        char quote = c; lx_advc(lx);
        size_t cap=32, len=0; char *buf=xmalloc(cap);
        while(lx_peekc(lx) && lx_peekc(lx)!=quote){
            int ch = lx_advc(lx);
            if(ch=='\\'){
                int e = lx_advc(lx);
                switch(e){
                    case 'n': ch='\n'; break;
                    case 't': ch='\t'; break;
                    case '"': ch='"'; break;
                    case '\'': ch='\''; break;
                    case '\\': ch='\\'; break;
                    default: ch=e;
                }
            }
            if(len+1>=cap){ cap*=2; buf=xrealloc(buf,cap); }
            buf[len++]=(char)ch;
        }
        lx_advc(lx);
        buf[len]=0;
        t.type=T_STRING; t.text=buf;
        return t;
    }
    lx_advc(lx);
    switch(c){
        case '+': t.type=T_PLUS; return t;
        case '-': t.type=T_MINUS; return t;
        case '*': t.type=T_STAR; return t;
        case '/': t.type=T_SLASH; return t;
        case '%': t.type=T_PERCENT; return t;
        case '^': t.type=T_CARET; return t;
        case '(': t.type=T_LPAREN; return t;
        case ')': t.type=T_RPAREN; return t;
        case '{': t.type=T_LBRACE; return t;
        case '}': t.type=T_RBRACE; return t;
        case '[': t.type=T_LBRACKET; return t;
        case ']': t.type=T_RBRACKET; return t;
        case ',': t.type=T_COMMA; return t;
        case ':': t.type=T_COLON; return t;
        case ';': t.type=T_SEMI; return t;
        case '.':
            if(lx_peekc(lx)=='.'){ lx_advc(lx); t.type=T_DOTDOT; return t; }
            t.type=T_DOT; return t;
        case '=':
            if(lx_peekc(lx)=='='){ lx_advc(lx); t.type=T_EQEQ; return t; }
            t.type=T_EQ; return t;
        case '~':
            if(lx_peekc(lx)=='='){ lx_advc(lx); t.type=T_NEQ; return t; }
            fprintf(stderr,"line %d: unexpected '~'\n", t.line); exit(1);
        case '<':
            if(lx_peekc(lx)=='='){ lx_advc(lx); t.type=T_LE; return t; }
            t.type=T_LT; return t;
        case '>':
            if(lx_peekc(lx)=='='){ lx_advc(lx); t.type=T_GE; return t; }
            t.type=T_GT; return t;
        default:
            fprintf(stderr,"line %d: unexpected char '%c'\n", t.line, c); exit(1);
    }
    return t;
}

static void lexer_prime(Lexer *lx){ lx->cur = lex_next_raw(lx); }
static void lexer_advance(Lexer *lx){
    if(lx->has_ahead){ lx->cur = lx->ahead; lx->has_ahead=0; }
    else lx->cur = lex_next_raw(lx);
}
static Token *lexer_peek_ahead(Lexer *lx){
    if(!lx->has_ahead){ lx->ahead = lex_next_raw(lx); lx->has_ahead=1; }
    return &lx->ahead;
}

typedef struct Expr Expr;
typedef struct Stat Stat;

typedef enum {
    E_NUM, E_STR, E_BOOL, E_NIL, E_NAME, E_BINOP, E_UNOP,
    E_CALL, E_METHODCALL, E_INDEX, E_FIELD, E_TABLE, E_FUNC, E_VARARG
} ExprType;

typedef struct ExprList { Expr *expr; struct ExprList *next; } ExprList;
typedef struct NameList { char *name; struct NameList *next; } NameList;
typedef struct StatList { Stat *stat; struct StatList *next; } StatList;

typedef struct {
    NameList *params;
    StatList *body;
} FuncBody;

struct Expr {
    ExprType type;
    int line;
    double num;
    char *str;
    int boolean;
    TokType op;
    Expr *a, *b;
    char *name;
    ExprList *args;
    FuncBody *func;
    struct TableField *fields;
};

typedef struct TableField {
    char *key;
    Expr *keyexpr;
    Expr *value;
    struct TableField *next;
} TableField;

typedef enum {
    S_EXPR, S_LOCAL, S_ASSIGN, S_IF, S_WHILE, S_NUMFOR, S_GENFOR,
    S_FUNCDECL, S_RETURN, S_BREAK, S_DO
} StatType;

typedef struct IfClause {
    Expr *cond;
    StatList *body;
    struct IfClause *next;
} IfClause;

struct Stat {
    StatType type;
    int line;
    NameList *names;
    ExprList *exprs;
    Expr *lhs;
    Expr *rhs;
    IfClause *clauses;
    StatList *elsebody;
    Expr *cond;
    StatList *body;
    char *varname;
    Expr *e1,*e2,*e3;
    char *funcname;
    Expr *funcnameexpr;
    FuncBody *func;
    Expr *retval;
    NameList *genvars;
    Expr *geniter;
};

typedef FuncBody FuncDecl;

static Expr *new_expr(ExprType t, int line){
    Expr *e = xmalloc(sizeof(Expr));
    memset(e,0,sizeof(Expr));
    e->type=t; e->line=line;
    return e;
}
static Stat *new_stat(StatType t, int line){
    Stat *s = xmalloc(sizeof(Stat));
    memset(s,0,sizeof(Stat));
    s->type=t; s->line=line;
    return s;
}

typedef struct {
    Lexer lx;
} Parser;

static void perror_at(int line, const char *msg){
    fprintf(stderr, "light: parse error near line %d: %s\n", line, msg);
    exit(1);
}

static int check(Parser *p, TokType t){ return p->lx.cur.type==t; }
static void expect(Parser *p, TokType t, const char *what){
    if(p->lx.cur.type!=t) perror_at(p->lx.cur.line, what);
    lexer_advance(&p->lx);
}
static int match(Parser *p, TokType t){
    if(check(p,t)){ lexer_advance(&p->lx); return 1; }
    return 0;
}

static Expr *parse_expr(Parser *p);
static StatList *parse_block(Parser *p);
static ExprList *parse_exprlist(Parser *p);

static FuncBody *parse_funcbody(Parser *p){
    FuncBody *fb = xmalloc(sizeof(FuncBody));
    fb->params=NULL; fb->body=NULL;
    expect(p,T_LPAREN,"expected '(' in function params");
    NameList *head=NULL, *tail=NULL;
    if(!check(p,T_RPAREN)){
        for(;;){
            if(!check(p,T_NAME)) perror_at(p->lx.cur.line,"expected parameter name");
            NameList *n = xmalloc(sizeof(NameList));
            n->name = xstrdup(p->lx.cur.text); n->next=NULL;
            lexer_advance(&p->lx);
            if(!head){ head=tail=n; } else { tail->next=n; tail=n; }
            if(!match(p,T_COMMA)) break;
        }
    }
    expect(p,T_RPAREN,"expected ')'");
    fb->params = head;
    fb->body = parse_block(p);
    expect(p,T_END,"expected 'end' to close function");
    return fb;
}

static TableField *parse_tablector(Parser *p){
    TableField *head=NULL, *tail=NULL;
    while(!check(p,T_RBRACE)){
        TableField *f = xmalloc(sizeof(TableField));
        f->key=NULL; f->keyexpr=NULL; f->next=NULL;
        if(check(p,T_LBRACKET)){
            lexer_advance(&p->lx);
            f->keyexpr = parse_expr(p);
            expect(p,T_RBRACKET,"expected ']'");
            expect(p,T_EQ,"expected '='");
            f->value = parse_expr(p);
        } else if(check(p,T_NAME) && lexer_peek_ahead(&p->lx)->type==T_EQ){
            f->key = xstrdup(p->lx.cur.text);
            lexer_advance(&p->lx);
            lexer_advance(&p->lx);
            f->value = parse_expr(p);
        } else {
            f->value = parse_expr(p);
        }
        if(!head){ head=tail=f; } else { tail->next=f; tail=f; }
        if(!match(p,T_COMMA) && !match(p,T_SEMI)) break;
    }
    expect(p,T_RBRACE,"expected '}'");
    return head;
}

static Expr *parse_primaryexpr(Parser *p){
    int line = p->lx.cur.line;
    if(check(p,T_LPAREN)){
        lexer_advance(&p->lx);
        Expr *e = parse_expr(p);
        expect(p,T_RPAREN,"expected ')'");
        return e;
    }
    if(check(p,T_NAME)){
        Expr *e = new_expr(E_NAME,line);
        e->name = xstrdup(p->lx.cur.text);
        lexer_advance(&p->lx);
        return e;
    }
    perror_at(line,"unexpected token in expression");
    return NULL;
}

static ExprList *parse_exprlist(Parser *p){
    ExprList *head=NULL,*tail=NULL;
    ExprList *n = xmalloc(sizeof(ExprList));
    n->expr = parse_expr(p); n->next=NULL;
    head=tail=n;
    while(match(p,T_COMMA)){
        ExprList *m = xmalloc(sizeof(ExprList));
        m->expr = parse_expr(p); m->next=NULL;
        tail->next=m; tail=m;
    }
    return head;
}

static Expr *parse_suffixedexpr(Parser *p){
    Expr *e = parse_primaryexpr(p);
    for(;;){
        int line = p->lx.cur.line;
        if(check(p,T_DOT)){
            lexer_advance(&p->lx);
            if(!check(p,T_NAME)) perror_at(line,"expected field name after '.'");
            Expr *f = new_expr(E_FIELD,line);
            f->a = e; f->name = xstrdup(p->lx.cur.text);
            lexer_advance(&p->lx);
            e = f;
        } else if(check(p,T_LBRACKET)){
            lexer_advance(&p->lx);
            Expr *idx = parse_expr(p);
            expect(p,T_RBRACKET,"expected ']'");
            Expr *f = new_expr(E_INDEX,line);
            f->a = e; f->b = idx;
            e = f;
        } else if(check(p,T_LPAREN)){
            lexer_advance(&p->lx);
            ExprList *args = NULL;
            if(!check(p,T_RPAREN)) args = parse_exprlist(p);
            expect(p,T_RPAREN,"expected ')'");
            Expr *c = new_expr(E_CALL,line);
            c->a = e; c->args = args;
            e = c;
        } else if(check(p,T_STRING)){
            Expr *arg = new_expr(E_STR, line);
            arg->str = xstrdup(p->lx.cur.text);
            lexer_advance(&p->lx);
            ExprList *args = xmalloc(sizeof(ExprList));
            args->expr = arg; args->next = NULL;
            Expr *c = new_expr(E_CALL,line);
            c->a = e; c->args = args;
            e = c;
        } else if(check(p,T_COLON)){
            lexer_advance(&p->lx);
            if(!check(p,T_NAME)) perror_at(line,"expected method name after ':'");
            char *mname = xstrdup(p->lx.cur.text);
            lexer_advance(&p->lx);
            expect(p,T_LPAREN,"expected '(' after method name");
            ExprList *args = NULL;
            if(!check(p,T_RPAREN)) args = parse_exprlist(p);
            expect(p,T_RPAREN,"expected ')'");
            Expr *c = new_expr(E_METHODCALL,line);
            c->a = e; c->name = mname; c->args = args;
            e = c;
        } else break;
    }
    return e;
}

static Expr *parse_simpleexpr(Parser *p){
    int line = p->lx.cur.line;
    if(check(p,T_NUMBER)){
        Expr *e = new_expr(E_NUM,line); e->num = p->lx.cur.num;
        lexer_advance(&p->lx); return e;
    }
    if(check(p,T_STRING)){
        Expr *e = new_expr(E_STR,line); e->str = xstrdup(p->lx.cur.text);
        lexer_advance(&p->lx); return e;
    }
    if(check(p,T_TRUE)){ lexer_advance(&p->lx); Expr *e=new_expr(E_BOOL,line); e->boolean=1; return e; }
    if(check(p,T_FALSE)){ lexer_advance(&p->lx); Expr *e=new_expr(E_BOOL,line); e->boolean=0; return e; }
    if(check(p,T_NIL)){ lexer_advance(&p->lx); return new_expr(E_NIL,line); }
    if(check(p,T_LBRACE)){
        lexer_advance(&p->lx);
        Expr *e = new_expr(E_TABLE,line);
        e->fields = parse_tablector(p);
        return e;
    }
    if(check(p,T_FUNCTION)){
        lexer_advance(&p->lx);
        Expr *e = new_expr(E_FUNC,line);
        e->func = parse_funcbody(p);
        return e;
    }
    return parse_suffixedexpr(p);
}

static Expr *parse_unary(Parser *p){
    int line = p->lx.cur.line;
    if(check(p,T_NOT)){ lexer_advance(&p->lx); Expr *e=new_expr(E_UNOP,line); e->op=T_NOT; e->a=parse_unary(p); return e; }
    if(check(p,T_MINUS)){ lexer_advance(&p->lx); Expr *e=new_expr(E_UNOP,line); e->op=T_MINUS; e->a=parse_unary(p); return e; }
    return parse_simpleexpr(p);
}

static Expr *parse_pow(Parser *p){
    Expr *e = parse_unary(p);
    if(check(p,T_CARET)){
        int line=p->lx.cur.line;
        lexer_advance(&p->lx);
        Expr *rhs = parse_pow(p);
        Expr *b = new_expr(E_BINOP,line); b->op=T_CARET; b->a=e; b->b=rhs;
        return b;
    }
    return e;
}
static Expr *parse_factor(Parser *p){
    Expr *e = parse_pow(p);
    while(check(p,T_STAR)||check(p,T_SLASH)||check(p,T_PERCENT)){
        TokType op = p->lx.cur.type; int line=p->lx.cur.line;
        lexer_advance(&p->lx);
        Expr *rhs = parse_pow(p);
        Expr *b = new_expr(E_BINOP,line); b->op=op; b->a=e; b->b=rhs;
        e=b;
    }
    return e;
}
static Expr *parse_term(Parser *p){
    Expr *e = parse_factor(p);
    while(check(p,T_PLUS)||check(p,T_MINUS)){
        TokType op = p->lx.cur.type; int line=p->lx.cur.line;
        lexer_advance(&p->lx);
        Expr *rhs = parse_factor(p);
        Expr *b = new_expr(E_BINOP,line); b->op=op; b->a=e; b->b=rhs;
        e=b;
    }
    return e;
}
static Expr *parse_concat(Parser *p){
    Expr *e = parse_term(p);
    if(check(p,T_DOTDOT)){
        int line=p->lx.cur.line;
        lexer_advance(&p->lx);
        Expr *rhs = parse_concat(p);
        Expr *b = new_expr(E_BINOP,line); b->op=T_DOTDOT; b->a=e; b->b=rhs;
        return b;
    }
    return e;
}
static Expr *parse_comparison(Parser *p){
    Expr *e = parse_concat(p);
    while(check(p,T_LT)||check(p,T_GT)||check(p,T_LE)||check(p,T_GE)||check(p,T_EQEQ)||check(p,T_NEQ)){
        TokType op = p->lx.cur.type; int line=p->lx.cur.line;
        lexer_advance(&p->lx);
        Expr *rhs = parse_concat(p);
        Expr *b = new_expr(E_BINOP,line); b->op=op; b->a=e; b->b=rhs;
        e=b;
    }
    return e;
}
static Expr *parse_and(Parser *p){
    Expr *e = parse_comparison(p);
    while(check(p,T_AND)){
        int line=p->lx.cur.line; lexer_advance(&p->lx);
        Expr *rhs = parse_comparison(p);
        Expr *b = new_expr(E_BINOP,line); b->op=T_AND; b->a=e; b->b=rhs;
        e=b;
    }
    return e;
}
static Expr *parse_or(Parser *p){
    Expr *e = parse_and(p);
    while(check(p,T_OR)){
        int line=p->lx.cur.line; lexer_advance(&p->lx);
        Expr *rhs = parse_and(p);
        Expr *b = new_expr(E_BINOP,line); b->op=T_OR; b->a=e; b->b=rhs;
        e=b;
    }
    return e;
}
static Expr *parse_expr(Parser *p){ return parse_or(p); }

static int stat_follow(Parser *p){
    return check(p,T_END)||check(p,T_ELSE)||check(p,T_ELSEIF)||check(p,T_EOF);
}

static Stat *parse_stat(Parser *p){
    int line = p->lx.cur.line;
    if(match(p,T_SEMI)) return NULL;
    if(check(p,T_LOCAL)){
        lexer_advance(&p->lx);
        if(check(p,T_FUNCTION)){
            lexer_advance(&p->lx);
            if(!check(p,T_NAME)) perror_at(line,"expected function name");
            Stat *s = new_stat(S_FUNCDECL,line);
            s->funcname = xstrdup(p->lx.cur.text);
            s->e1 = NULL;
            lexer_advance(&p->lx);
            s->func = parse_funcbody(p);
            s->names = xmalloc(sizeof(NameList));
            s->names->name = xstrdup(s->funcname); s->names->next=NULL;
            s->type = S_LOCAL;
            Expr *fe = new_expr(E_FUNC,line); fe->func = s->func;
            s->exprs = xmalloc(sizeof(ExprList));
            s->exprs->expr = fe; s->exprs->next = NULL;
            return s;
        }
        Stat *s = new_stat(S_LOCAL,line);
        NameList *head=NULL,*tail=NULL;
        for(;;){
            if(!check(p,T_NAME)) perror_at(line,"expected name after 'local'");
            NameList *n = xmalloc(sizeof(NameList));
            n->name = xstrdup(p->lx.cur.text); n->next=NULL;
            lexer_advance(&p->lx);
            if(!head){head=tail=n;} else {tail->next=n; tail=n;}
            if(!match(p,T_COMMA)) break;
        }
        s->names = head;
        if(match(p,T_EQ)){
            s->exprs = parse_exprlist(p);
        } else s->exprs = NULL;
        return s;
    }
    if(check(p,T_FUNCTION)){
        lexer_advance(&p->lx);
        if(!check(p,T_NAME)) perror_at(line,"expected function name");
        Expr *target = new_expr(E_NAME,line);
        target->name = xstrdup(p->lx.cur.text);
        lexer_advance(&p->lx);
        while(check(p,T_DOT)){
            lexer_advance(&p->lx);
            if(!check(p,T_NAME)) perror_at(line,"expected name after '.'");
            Expr *f = new_expr(E_FIELD,line);
            f->a = target; f->name = xstrdup(p->lx.cur.text);
            lexer_advance(&p->lx);
            target = f;
        }
        Stat *s = new_stat(S_ASSIGN,line);
        s->lhs = target;
        Expr *fe = new_expr(E_FUNC,line);
        fe->func = parse_funcbody(p);
        s->rhs = fe;
        return s;
    }
    if(check(p,T_IF)){
        lexer_advance(&p->lx);
        Stat *s = new_stat(S_IF,line);
        IfClause *head=NULL,*tail=NULL;
        IfClause *c = xmalloc(sizeof(IfClause));
        c->cond = parse_expr(p);
        expect(p,T_THEN,"expected 'then'");
        c->body = parse_block(p);
        c->next=NULL;
        head=tail=c;
        while(check(p,T_ELSEIF)){
            lexer_advance(&p->lx);
            IfClause *c2 = xmalloc(sizeof(IfClause));
            c2->cond = parse_expr(p);
            expect(p,T_THEN,"expected 'then'");
            c2->body = parse_block(p);
            c2->next=NULL;
            tail->next=c2; tail=c2;
        }
        s->clauses = head;
        if(check(p,T_ELSE)){
            lexer_advance(&p->lx);
            s->elsebody = parse_block(p);
        }
        expect(p,T_END,"expected 'end' to close if");
        return s;
    }
    if(check(p,T_WHILE)){
        lexer_advance(&p->lx);
        Stat *s = new_stat(S_WHILE,line);
        s->cond = parse_expr(p);
        expect(p,T_DO,"expected 'do'");
        s->body = parse_block(p);
        expect(p,T_END,"expected 'end' to close while");
        return s;
    }
    if(check(p,T_DO)){
        lexer_advance(&p->lx);
        Stat *s = new_stat(S_DO,line);
        s->body = parse_block(p);
        expect(p,T_END,"expected 'end' to close do");
        return s;
    }
    if(check(p,T_FOR)){
        lexer_advance(&p->lx);
        if(!check(p,T_NAME)) perror_at(line,"expected name after 'for'");
        char *n1 = xstrdup(p->lx.cur.text);
        lexer_advance(&p->lx);
        if(check(p,T_EQ)){
            lexer_advance(&p->lx);
            Stat *s = new_stat(S_NUMFOR,line);
            s->varname = n1;
            s->e1 = parse_expr(p);
            expect(p,T_COMMA,"expected ','");
            s->e2 = parse_expr(p);
            if(match(p,T_COMMA)) s->e3 = parse_expr(p); else s->e3=NULL;
            expect(p,T_DO,"expected 'do'");
            s->body = parse_block(p);
            expect(p,T_END,"expected 'end' to close for");
            return s;
        } else {
            NameList *head = xmalloc(sizeof(NameList));
            head->name = n1; head->next=NULL;
            NameList *tail = head;
            while(match(p,T_COMMA)){
                if(!check(p,T_NAME)) perror_at(line,"expected name");
                NameList *n = xmalloc(sizeof(NameList));
                n->name = xstrdup(p->lx.cur.text); n->next=NULL;
                lexer_advance(&p->lx);
                tail->next=n; tail=n;
            }
            expect(p,T_IN,"expected 'in'");
            Stat *s = new_stat(S_GENFOR,line);
            s->genvars = head;
            s->geniter = parse_expr(p);
            expect(p,T_DO,"expected 'do'");
            s->body = parse_block(p);
            expect(p,T_END,"expected 'end' to close for");
            return s;
        }
    }
    if(check(p,T_RETURN)){
        lexer_advance(&p->lx);
        Stat *s = new_stat(S_RETURN,line);
        if(!stat_follow(p) && !check(p,T_SEMI)) s->retval = parse_expr(p);
        else s->retval = NULL;
        match(p,T_SEMI);
        return s;
    }
    if(check(p,T_BREAK)){
        lexer_advance(&p->lx);
        return new_stat(S_BREAK,line);
    }
    Expr *e = parse_suffixedexpr(p);
    if(check(p,T_EQ)){
        lexer_advance(&p->lx);
        Stat *s = new_stat(S_ASSIGN,line);
        s->lhs = e;
        s->rhs = parse_expr(p);
        return s;
    }
    Stat *s = new_stat(S_EXPR,line);
    s->lhs = e;
    return s;
}

static StatList *parse_block(Parser *p){
    StatList *head=NULL,*tail=NULL;
    while(!stat_follow(p)){
        Stat *s = parse_stat(p);
        if(!s) continue;
        StatList *n = xmalloc(sizeof(StatList));
        n->stat = s; n->next=NULL;
        if(!head){head=tail=n;} else {tail->next=n; tail=n;}
    }
    return head;
}

static StatList *parse_program(const char *src){
    Parser p;
    lexer_init(&p.lx, src);
    lexer_prime(&p.lx);
    StatList *b = parse_block(&p);
    if(!check(&p,T_EOF)) perror_at(p.lx.cur.line,"unexpected token, expected end of file");
    return b;
}

typedef enum { V_NIL, V_BOOL, V_NUM, V_STR, V_TABLE, V_FUNC, V_NATIVE } VType;
typedef struct Value Value;
typedef struct Table Table;
typedef struct Env Env;

typedef Value (*NativeFn)(Value *args, int argc);

typedef struct {
    FuncBody *body;
    Env *closure;
} LClosure;

struct Value {
    VType type;
    union {
        int b;
        double n;
        char *s;
        Table *t;
        LClosure *f;
        NativeFn native;
    } as;
};

typedef struct Entry {
    char *key;
    Value val;
    struct Entry *next;
} Entry;

struct Table {
    Entry **buckets;
    int nbuckets;
    int count;
};

static Table *table_new(void){
    Table *t = xmalloc(sizeof(Table));
    t->nbuckets = 16;
    t->buckets = xmalloc(sizeof(Entry*)*t->nbuckets);
    memset(t->buckets,0,sizeof(Entry*)*t->nbuckets);
    t->count=0;
    return t;
}
static unsigned long hashstr(const char *s){
    unsigned long h=5381; int c;
    while((c=*s++)) h = ((h<<5)+h)+c;
    return h;
}
static Value make_nil(void){ Value v; v.type=V_NIL; return v; }
static Value make_bool(int b){ Value v; v.type=V_BOOL; v.as.b=b; return v; }
static Value make_num(double n){ Value v; v.type=V_NUM; v.as.n=n; return v; }
static Value make_str(const char *s){ Value v; v.type=V_STR; v.as.s=xstrdup(s); return v; }
static Value make_str_owned(char *s){ Value v; v.type=V_STR; v.as.s=s; return v; }
static Value make_table(Table *t){ Value v; v.type=V_TABLE; v.as.t=t; return v; }
static Value make_func(LClosure *f){ Value v; v.type=V_FUNC; v.as.f=f; return v; }
static Value make_native(NativeFn f){ Value v; v.type=V_NATIVE; v.as.native=f; return v; }

static void table_set(Table *t, const char *key, Value v){
    unsigned long h = hashstr(key) % t->nbuckets;
    Entry *e = t->buckets[h];
    while(e){ if(strcmp(e->key,key)==0){ e->val=v; return; } e=e->next; }
    Entry *n = xmalloc(sizeof(Entry));
    n->key = xstrdup(key); n->val = v; n->next = t->buckets[h];
    t->buckets[h] = n;
    t->count++;
}
static Value table_get(Table *t, const char *key){
    unsigned long h = hashstr(key) % t->nbuckets;
    Entry *e = t->buckets[h];
    while(e){ if(strcmp(e->key,key)==0) return e->val; e=e->next; }
    return make_nil();
}
static char *numkey(double n){
    static char buf[64];
    if(n == (long long)n) snprintf(buf,sizeof(buf),"%lld",(long long)n);
    else snprintf(buf,sizeof(buf),"%g",n);
    return buf;
}

typedef struct EnvEntry { char *name; Value val; struct EnvEntry *next; } EnvEntry;
struct Env {
    EnvEntry *vars;
    Env *parent;
};
static Env *env_new(Env *parent){
    Env *e = xmalloc(sizeof(Env)); e->vars=NULL; e->parent=parent; return e;
}
static void env_define(Env *e, const char *name, Value v){
    EnvEntry *n = xmalloc(sizeof(EnvEntry));
    n->name = xstrdup(name); n->val = v; n->next = e->vars;
    e->vars = n;
}
static int env_set(Env *e, const char *name, Value v){
    for(Env *cur=e; cur; cur=cur->parent){
        for(EnvEntry *v2=cur->vars; v2; v2=v2->next){
            if(strcmp(v2->name,name)==0){ v2->val=v; return 1; }
        }
    }
    return 0;
}
static int env_get(Env *e, const char *name, Value *out){
    for(Env *cur=e; cur; cur=cur->parent){
        for(EnvEntry *v2=cur->vars; v2; v2=v2->next){
            if(strcmp(v2->name,name)==0){ *out=v2->val; return 1; }
        }
    }
    return 0;
}

typedef enum { FLOW_NONE, FLOW_RETURN, FLOW_BREAK } FlowType;
static FlowType g_flow = FLOW_NONE;
static Value g_retval;

static Env *g_globals = NULL;

static int truthy(Value v){
    if(v.type==V_NIL) return 0;
    if(v.type==V_BOOL) return v.as.b;
    return 1;
}
static const char *typenames[] = {"nil","boolean","number","string","table","function","function"};

static void runtime_error(int line, const char *fmt, ...){
    va_list ap; va_start(ap,fmt);
    fprintf(stderr, "light: runtime error at line %d: ", line);
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    va_end(ap);
    exit(1);
}

static char *value_tostring(Value v){
    char buf[256];
    switch(v.type){
        case V_NIL: return xstrdup("nil");
        case V_BOOL: return xstrdup(v.as.b ? "true":"false");
        case V_NUM:
            if(v.as.n == (long long)v.as.n) snprintf(buf,sizeof(buf),"%lld",(long long)v.as.n);
            else snprintf(buf,sizeof(buf),"%g",v.as.n);
            return xstrdup(buf);
        case V_STR: return xstrdup(v.as.s);
        case V_TABLE: snprintf(buf,sizeof(buf),"table: %p",(void*)v.as.t); return xstrdup(buf);
        case V_FUNC: case V_NATIVE: snprintf(buf,sizeof(buf),"function: %p",(void*)&v); return xstrdup(buf);
    }
    return xstrdup("?");
}

static Expr *g_notused;

static Value eval_expr(Expr *e, Env *env);
static void exec_block(StatList *b, Env *env);
static Value call_value(Value fn, Value *args, int argc, int line);

static Value *eval_arglist(ExprList *args, Env *env, int *outcount){
    int n=0; for(ExprList *c=args;c;c=c->next) n++;
    Value *arr = n? xmalloc(sizeof(Value)*n) : NULL;
    int i=0;
    for(ExprList *c=args;c;c=c->next){ arr[i++] = eval_expr(c->expr, env); }
    *outcount = n;
    return arr;
}

static Value eval_call(Expr *e, Env *env){
    Value fn = eval_expr(e->a, env);
    int argc;
    Value *args = eval_arglist(e->args, env, &argc);
    Value r = call_value(fn, args, argc, e->line);
    if(args) free(args);
    return r;
}

static Value eval_methodcall(Expr *e, Env *env){
    Value obj = eval_expr(e->a, env);
    if(obj.type != V_TABLE) runtime_error(e->line, "attempt to index a non-table value for method '%s'", e->name);
    Value fn = table_get(obj.as.t, e->name);
    int argc;
    Value *rest = eval_arglist(e->args, env, &argc);
    Value *args = xmalloc(sizeof(Value)*(argc+1));
    args[0] = obj;
    for(int i=0;i<argc;i++) args[i+1]=rest[i];
    if(rest) free(rest);
    Value r = call_value(fn, args, argc+1, e->line);
    free(args);
    return r;
}

static double tonum(Value v, int line){
    if(v.type==V_NUM) return v.as.n;
    if(v.type==V_STR) return atof(v.as.s);
    runtime_error(line, "attempt to perform arithmetic on a %s value", typenames[v.type]);
    return 0;
}

static Value eval_binop(Expr *e, Env *env){
    if(e->op==T_AND){
        Value a = eval_expr(e->a,env);
        if(!truthy(a)) return a;
        return eval_expr(e->b,env);
    }
    if(e->op==T_OR){
        Value a = eval_expr(e->a,env);
        if(truthy(a)) return a;
        return eval_expr(e->b,env);
    }
    Value a = eval_expr(e->a, env);
    Value b = eval_expr(e->b, env);
    switch(e->op){
        case T_PLUS: return make_num(tonum(a,e->line)+tonum(b,e->line));
        case T_MINUS: return make_num(tonum(a,e->line)-tonum(b,e->line));
        case T_STAR: return make_num(tonum(a,e->line)*tonum(b,e->line));
        case T_SLASH: return make_num(tonum(a,e->line)/tonum(b,e->line));
        case T_PERCENT: return make_num(fmod(tonum(a,e->line),tonum(b,e->line)));
        case T_CARET: return make_num(pow(tonum(a,e->line),tonum(b,e->line)));
        case T_DOTDOT: {
            char *sa = value_tostring(a);
            char *sb = value_tostring(b);
            char *r = xmalloc(strlen(sa)+strlen(sb)+1);
            strcpy(r,sa); strcat(r,sb);
            free(sa); free(sb);
            return make_str_owned(r);
        }
        case T_EQEQ: {
            if(a.type!=b.type) return make_bool(0);
            switch(a.type){
                case V_NIL: return make_bool(1);
                case V_BOOL: return make_bool(a.as.b==b.as.b);
                case V_NUM: return make_bool(a.as.n==b.as.n);
                case V_STR: return make_bool(strcmp(a.as.s,b.as.s)==0);
                case V_TABLE: return make_bool(a.as.t==b.as.t);
                default: return make_bool(0);
            }
        }
        case T_NEQ: {
            Value eq = eval_binop((Expr[]){{.type=E_BINOP,.op=T_EQEQ,.a=e->a,.b=e->b,.line=e->line}}, env);
            return make_bool(!truthy(eq));
        }
        case T_LT:
            if(a.type==V_STR && b.type==V_STR) return make_bool(strcmp(a.as.s,b.as.s)<0);
            return make_bool(tonum(a,e->line)<tonum(b,e->line));
        case T_LE:
            if(a.type==V_STR && b.type==V_STR) return make_bool(strcmp(a.as.s,b.as.s)<=0);
            return make_bool(tonum(a,e->line)<=tonum(b,e->line));
        case T_GT:
            if(a.type==V_STR && b.type==V_STR) return make_bool(strcmp(a.as.s,b.as.s)>0);
            return make_bool(tonum(a,e->line)>tonum(b,e->line));
        case T_GE:
            if(a.type==V_STR && b.type==V_STR) return make_bool(strcmp(a.as.s,b.as.s)>=0);
            return make_bool(tonum(a,e->line)>=tonum(b,e->line));
        default: break;
    }
    runtime_error(e->line,"unsupported binary operator");
    return make_nil();
}

static Value eval_expr(Expr *e, Env *env){
    switch(e->type){
        case E_NUM: return make_num(e->num);
        case E_STR: return make_str(e->str);
        case E_BOOL: return make_bool(e->boolean);
        case E_NIL: return make_nil();
        case E_NAME: {
            Value v;
            if(env_get(env, e->name, &v)) return v;
            return make_nil();
        }
        case E_UNOP: {
            Value a = eval_expr(e->a, env);
            if(e->op==T_NOT) return make_bool(!truthy(a));
            if(e->op==T_MINUS) return make_num(-tonum(a,e->line));
            break;
        }
        case E_BINOP: return eval_binop(e, env);
        case E_CALL: return eval_call(e, env);
        case E_METHODCALL: return eval_methodcall(e, env);
        case E_FIELD: {
            Value a = eval_expr(e->a, env);
            if(a.type != V_TABLE){
                runtime_error(e->line, "attempt to index a %s value (field '%s')", typenames[a.type], e->name);
            }
            return table_get(a.as.t, e->name);
        }
        case E_INDEX: {
            Value a = eval_expr(e->a, env);
            Value idx = eval_expr(e->b, env);
            if(a.type != V_TABLE) runtime_error(e->line, "attempt to index a %s value", typenames[a.type]);
            char *k = (idx.type==V_NUM) ? numkey(idx.as.n) : value_tostring(idx);
            Value r = table_get(a.as.t, k);
            if(idx.type!=V_NUM) free(k);
            return r;
        }
        case E_TABLE: {
            Table *t = table_new();
            int arrayidx = 1;
            for(TableField *f = e->fields; f; f=f->next){
                Value v = eval_expr(f->value, env);
                if(f->key){
                    table_set(t, f->key, v);
                } else if(f->keyexpr){
                    Value k = eval_expr(f->keyexpr, env);
                    char *ks = (k.type==V_NUM)? numkey(k.as.n): value_tostring(k);
                    table_set(t, ks, v);
                    if(k.type!=V_NUM) free(ks);
                } else {
                    table_set(t, numkey(arrayidx++), v);
                }
            }
            return make_table(t);
        }
        case E_FUNC: {
            LClosure *c = xmalloc(sizeof(LClosure));
            c->body = e->func; c->closure = env;
            return make_func(c);
        }
        default: break;
    }
    runtime_error(e->line, "invalid expression");
    return make_nil();
}

static Value call_value(Value fn, Value *args, int argc, int line){
    if(fn.type==V_NATIVE){
        return fn.as.native(args, argc);
    }
    if(fn.type==V_FUNC){
        Env *fenv = env_new(fn.as.f->closure);
        NameList *p = fn.as.f->body->params;
        int i=0;
        while(p){
            env_define(fenv, p->name, i<argc? args[i] : make_nil());
            p=p->next; i++;
        }
        g_flow = FLOW_NONE;
        exec_block(fn.as.f->body->body, fenv);
        if(g_flow==FLOW_RETURN){ g_flow=FLOW_NONE; return g_retval; }
        return make_nil();
    }
    runtime_error(line, "attempt to call a %s value", fn.type<=V_NATIVE? typenames[fn.type] : "unknown");
    return make_nil();
}

static void assign_to(Expr *lhs, Value v, Env *env){
    if(lhs->type==E_NAME){
        if(!env_set(env, lhs->name, v)){
            env_define(g_globals, lhs->name, v);
        }
        return;
    }
    if(lhs->type==E_FIELD){
        Value a = eval_expr(lhs->a, env);
        if(a.type != V_TABLE) runtime_error(lhs->line, "attempt to index a %s value", typenames[a.type]);
        table_set(a.as.t, lhs->name, v);
        return;
    }
    if(lhs->type==E_INDEX){
        Value a = eval_expr(lhs->a, env);
        Value idx = eval_expr(lhs->b, env);
        if(a.type != V_TABLE) runtime_error(lhs->line, "attempt to index a %s value", typenames[a.type]);
        char *k = (idx.type==V_NUM) ? numkey(idx.as.n) : value_tostring(idx);
        table_set(a.as.t, k, v);
        if(idx.type!=V_NUM) free(k);
        return;
    }
    runtime_error(lhs->line, "invalid assignment target");
}

static void exec_stat(Stat *s, Env *env){
    switch(s->type){
        case S_EXPR: eval_expr(s->lhs, env); break;
        case S_LOCAL: {
            NameList *n = s->names;
            ExprList *ex = s->exprs;
            while(n){
                Value v = make_nil();
                if(ex){ v = eval_expr(ex->expr, env); ex = ex->next; }
                env_define(env, n->name, v);
                n=n->next;
            }
            break;
        }
        case S_ASSIGN: {
            Value v = eval_expr(s->rhs, env);
            assign_to(s->lhs, v, env);
            break;
        }
        case S_IF: {
            for(IfClause *c=s->clauses; c; c=c->next){
                if(truthy(eval_expr(c->cond, env))){
                    Env *benv = env_new(env);
                    exec_block(c->body, benv);
                    return;
                }
            }
            if(s->elsebody){
                Env *benv = env_new(env);
                exec_block(s->elsebody, benv);
            }
            break;
        }
        case S_WHILE: {
            while(truthy(eval_expr(s->cond, env))){
                Env *benv = env_new(env);
                exec_block(s->body, benv);
                if(g_flow==FLOW_BREAK){ g_flow=FLOW_NONE; break; }
                if(g_flow==FLOW_RETURN) break;
            }
            break;
        }
        case S_NUMFOR: {
            double start = tonum(eval_expr(s->e1,env), s->line);
            double stop = tonum(eval_expr(s->e2,env), s->line);
            double step = s->e3 ? tonum(eval_expr(s->e3,env), s->line) : 1.0;
            for(double i=start; (step>0? i<=stop : i>=stop); i+=step){
                Env *benv = env_new(env);
                env_define(benv, s->varname, make_num(i));
                exec_block(s->body, benv);
                if(g_flow==FLOW_BREAK){ g_flow=FLOW_NONE; break; }
                if(g_flow==FLOW_RETURN) break;
            }
            break;
        }
        case S_GENFOR: {
            Value iterv = eval_expr(s->geniter, env);
            if(iterv.type==V_TABLE){
                Table *t = iterv.as.t;
                for(int b=0;b<t->nbuckets;b++){
                    for(Entry *en=t->buckets[b]; en; en=en->next){
                        Env *benv = env_new(env);
                        NameList *nv = s->genvars;
                        if(nv){ env_define(benv, nv->name, make_str(en->key)); nv=nv->next; }
                        if(nv){ env_define(benv, nv->name, en->val); }
                        exec_block(s->body, benv);
                        if(g_flow==FLOW_BREAK){ g_flow=FLOW_NONE; goto genfor_done; }
                        if(g_flow==FLOW_RETURN) goto genfor_done;
                    }
                }
            }
            genfor_done:;
            break;
        }
        case S_DO: {
            Env *benv = env_new(env);
            exec_block(s->body, benv);
            break;
        }
        case S_RETURN: {
            g_retval = s->retval ? eval_expr(s->retval, env) : make_nil();
            g_flow = FLOW_RETURN;
            break;
        }
        case S_BREAK: {
            g_flow = FLOW_BREAK;
            break;
        }
        default: break;
    }
}

static void exec_block(StatList *b, Env *env){
    for(StatList *c=b; c; c=c->next){
        exec_stat(c->stat, env);
        if(g_flow != FLOW_NONE) return;
    }
}

static Value arg(Value *args, int argc, int i){ return i<argc? args[i] : make_nil(); }

static Value native_print(Value *args, int argc){
    for(int i=0;i<argc;i++){
        char *s = value_tostring(args[i]);
        fputs(s, stdout);
        free(s);
        if(i<argc-1) fputc('\t', stdout);
    }
    fputc('\n', stdout);
    return make_nil();
}
static Value native_tostring(Value *args, int argc){
    return make_str_owned(value_tostring(arg(args,argc,0)));
}
static Value native_tonumber(Value *args, int argc){
    Value a = arg(args,argc,0);
    if(a.type==V_NUM) return a;
    if(a.type==V_STR) return make_num(atof(a.as.s));
    return make_nil();
}
static Value native_type(Value *args, int argc){
    Value a = arg(args,argc,0);
    return make_str(typenames[a.type]);
}
static Value native_random(Value *args, int argc){
    if(argc>=2){
        double lo = tonum(arg(args,argc,0),0);
        double hi = tonum(arg(args,argc,1),0);
        long r = (long)lo + rand() % (long)(hi-lo+1);
        return make_num((double)r);
    }
    if(argc==1){
        double hi = tonum(arg(args,argc,0),0);
        return make_num((double)(1 + rand() % (long)hi));
    }
    return make_num((double)rand()/RAND_MAX);
}
static Value native_floor(Value *args,int argc){ return make_num(floor(tonum(arg(args,argc,0),0))); }
static Value native_ceil(Value *args,int argc){ return make_num(ceil(tonum(arg(args,argc,0),0))); }
static Value native_abs(Value *args,int argc){ return make_num(fabs(tonum(arg(args,argc,0),0))); }
static Value native_sqrt(Value *args,int argc){ return make_num(sqrt(tonum(arg(args,argc,0),0))); }
static Value native_sin(Value *args,int argc){ return make_num(sin(tonum(arg(args,argc,0),0))); }
static Value native_cos(Value *args,int argc){ return make_num(cos(tonum(arg(args,argc,0),0))); }
static Value native_max(Value *args,int argc){
    double m = tonum(arg(args,argc,0),0);
    for(int i=1;i<argc;i++){ double v=tonum(args[i],0); if(v>m) m=v; }
    return make_num(m);
}
static Value native_min(Value *args,int argc){
    double m = tonum(arg(args,argc,0),0);
    for(int i=1;i<argc;i++){ double v=tonum(args[i],0); if(v<m) m=v; }
    return make_num(m);
}
static Value native_len(Value *args,int argc){
    Value a = arg(args,argc,0);
    if(a.type==V_STR) return make_num((double)strlen(a.as.s));
    if(a.type==V_TABLE){
        int n=0;
        for(int i=1;;i++){
            Value v = table_get(a.as.t, numkey(i));
            if(v.type==V_NIL) break;
            n++;
        }
        return make_num((double)n);
    }
    return make_num(0);
}

static void register_natives(Env *g){
    env_define(g,"print", make_native(native_print));
    env_define(g,"tostring", make_native(native_tostring));
    env_define(g,"tonumber", make_native(native_tonumber));
    env_define(g,"type", make_native(native_type));
    env_define(g,"len", make_native(native_len));

    Table *m = table_new();
    m->buckets[0]=NULL;
    table_set(m,"random", make_native(native_random));
    table_set(m,"floor", make_native(native_floor));
    table_set(m,"ceil", make_native(native_ceil));
    table_set(m,"abs", make_native(native_abs));
    table_set(m,"sqrt", make_native(native_sqrt));
    table_set(m,"sin", make_native(native_sin));
    table_set(m,"cos", make_native(native_cos));
    table_set(m,"max", make_native(native_max));
    table_set(m,"min", make_native(native_min));
    table_set(m,"pi", make_num(3.14159265358979323846));
    env_define(g,"math", make_table(m));
}

#ifdef LIGHT_GRAPHICS

#define MAX_TEXTURES 256
#define MAX_SOUNDS 256
static Texture2D g_textures[MAX_TEXTURES];
static int g_texture_count = 0;
static Sound g_sounds[MAX_SOUNDS];
static int g_sound_count = 0;
static Music g_musics[MAX_SOUNDS];
static int g_music_count = 0;
static int g_audio_ready = 0;

static Value native_window_open(Value *args,int argc){
    int w = (int)tonum(arg(args,argc,0),0);
    int h = (int)tonum(arg(args,argc,1),0);
    Value title = arg(args,argc,2);
    const char *t = title.type==V_STR ? title.as.s : "Light";
    InitWindow(w,h,t);
    SetTargetFPS(60);
    InitAudioDevice();
    g_audio_ready = 1;
    return make_nil();
}
static Value native_window_close(Value *args,int argc){
    (void)args;(void)argc;
    if(g_audio_ready){ CloseAudioDevice(); g_audio_ready=0; }
    CloseWindow();
    return make_nil();
}
static Value native_window_shouldclose(Value *args,int argc){
    (void)args;(void)argc;
    return make_bool(WindowShouldClose());
}
static Value native_window_settitle(Value *args,int argc){
    Value t = arg(args,argc,0);
    if(t.type==V_STR) SetWindowTitle(t.as.s);
    return make_nil();
}

static Value native_time_dt(Value *args,int argc){ (void)args;(void)argc; return make_num(GetFrameTime()); }
static Value native_time_now(Value *args,int argc){ (void)args;(void)argc; return make_num(GetTime()); }

static Color make_color(double r,double g,double b,double a){
    Color c; c.r=(unsigned char)r; c.g=(unsigned char)g; c.b=(unsigned char)b; c.a=(unsigned char)a;
    return c;
}
static Color color_from_args(Value *args,int argc,int start){
    double r = argc>start ? tonum(args[start],0) : 255;
    double g = argc>start+1 ? tonum(args[start+1],0) : 255;
    double b = argc>start+2 ? tonum(args[start+2],0) : 255;
    double a = argc>start+3 ? tonum(args[start+3],0) : 255;
    return make_color(r,g,b,a);
}

static Value native_draw_begin(Value *args,int argc){ (void)args;(void)argc; BeginDrawing(); return make_nil(); }
static Value native_draw_end(Value *args,int argc){ (void)args;(void)argc; EndDrawing(); return make_nil(); }
static Value native_draw_clear(Value *args,int argc){
    ClearBackground(color_from_args(args,argc,0));
    return make_nil();
}
static Value native_draw_rect(Value *args,int argc){
    double x=tonum(arg(args,argc,0),0), y=tonum(arg(args,argc,1),0);
    double w=tonum(arg(args,argc,2),0), h=tonum(arg(args,argc,3),0);
    Color c = color_from_args(args,argc,4);
    DrawRectangle((int)x,(int)y,(int)w,(int)h,c);
    return make_nil();
}
static Value native_draw_circle(Value *args,int argc){
    double x=tonum(arg(args,argc,0),0), y=tonum(arg(args,argc,1),0);
    double r=tonum(arg(args,argc,2),0);
    Color c = color_from_args(args,argc,3);
    DrawCircle((int)x,(int)y,(float)r,c);
    return make_nil();
}
static Value native_draw_line(Value *args,int argc){
    double x1=tonum(arg(args,argc,0),0), y1=tonum(arg(args,argc,1),0);
    double x2=tonum(arg(args,argc,2),0), y2=tonum(arg(args,argc,3),0);
    Color c = color_from_args(args,argc,4);
    DrawLine((int)x1,(int)y1,(int)x2,(int)y2,c);
    return make_nil();
}
static Value native_draw_text(Value *args,int argc){
    Value t = arg(args,argc,0);
    const char *txt = t.type==V_STR ? t.as.s : "";
    double x=tonum(arg(args,argc,1),0), y=tonum(arg(args,argc,2),0);
    double size=argc>3? tonum(args[3],0) : 20;
    Color c = color_from_args(args,argc,4);
    DrawText(txt,(int)x,(int)y,(int)size,c);
    return make_nil();
}
static Value native_draw_screenshot(Value *args,int argc){
    Value path = arg(args,argc,0);
    if(path.type==V_STR) TakeScreenshot(path.as.s);
    return make_nil();
}
static Value native_draw_fps(Value *args,int argc){
    double x=tonum(arg(args,argc,0),0), y=tonum(arg(args,argc,1),0);
    DrawFPS((int)x,(int)y);
    return make_nil();
}

static Value native_image_load(Value *args,int argc){
    Value path = arg(args,argc,0);
    if(path.type!=V_STR || g_texture_count>=MAX_TEXTURES) return make_num(-1);
    Texture2D tex = LoadTexture(path.as.s);
    g_textures[g_texture_count] = tex;
    return make_num(g_texture_count++);
}
static Value native_image_draw(Value *args,int argc){
    int id = (int)tonum(arg(args,argc,0),0);
    double x=tonum(arg(args,argc,1),0), y=tonum(arg(args,argc,2),0);
    if(id<0||id>=g_texture_count) return make_nil();
    double scale = argc>3? tonum(args[3],0) : 1.0;
    Texture2D tex = g_textures[id];
    DrawTextureEx(tex,(Vector2){(float)x,(float)y},0.0f,(float)scale,WHITE);
    return make_nil();
}
static Value native_image_width(Value *args,int argc){
    int id = (int)tonum(arg(args,argc,0),0);
    if(id<0||id>=g_texture_count) return make_num(0);
    return make_num(g_textures[id].width);
}
static Value native_image_height(Value *args,int argc){
    int id = (int)tonum(arg(args,argc,0),0);
    if(id<0||id>=g_texture_count) return make_num(0);
    return make_num(g_textures[id].height);
}

static Value native_input_key(Value *args,int argc){
    Value k = arg(args,argc,0);
    if(k.type!=V_STR) return make_bool(0);
    const char *s = k.as.s;
    int code = -1;
    if(strlen(s)==1){
        char c = toupper(s[0]);
        if(c>='A'&&c<='Z') code = KEY_A + (c-'A');
        else if(c>='0'&&c<='9') code = KEY_ZERO + (c-'0');
    } else if(strcmp(s,"space")==0) code=KEY_SPACE;
    else if(strcmp(s,"up")==0) code=KEY_UP;
    else if(strcmp(s,"down")==0) code=KEY_DOWN;
    else if(strcmp(s,"left")==0) code=KEY_LEFT;
    else if(strcmp(s,"right")==0) code=KEY_RIGHT;
    else if(strcmp(s,"enter")==0) code=KEY_ENTER;
    else if(strcmp(s,"escape")==0) code=KEY_ESCAPE;
    if(code<0) return make_bool(0);
    return make_bool(IsKeyDown(code));
}
static Value native_input_keypressed(Value *args,int argc){
    Value k = arg(args,argc,0);
    if(k.type!=V_STR) return make_bool(0);
    const char *s = k.as.s;
    int code = -1;
    if(strlen(s)==1){
        char c = toupper(s[0]);
        if(c>='A'&&c<='Z') code = KEY_A + (c-'A');
        else if(c>='0'&&c<='9') code = KEY_ZERO + (c-'0');
    } else if(strcmp(s,"space")==0) code=KEY_SPACE;
    else if(strcmp(s,"up")==0) code=KEY_UP;
    else if(strcmp(s,"down")==0) code=KEY_DOWN;
    else if(strcmp(s,"left")==0) code=KEY_LEFT;
    else if(strcmp(s,"right")==0) code=KEY_RIGHT;
    else if(strcmp(s,"enter")==0) code=KEY_ENTER;
    else if(strcmp(s,"escape")==0) code=KEY_ESCAPE;
    if(code<0) return make_bool(0);
    return make_bool(IsKeyPressed(code));
}
static Value native_input_mousedown(Value *args,int argc){
    (void)args;(void)argc;
    return make_bool(IsMouseButtonDown(MOUSE_BUTTON_LEFT));
}
static Value native_input_mousex(Value *args,int argc){ (void)args;(void)argc; return make_num(GetMouseX()); }
static Value native_input_mousey(Value *args,int argc){ (void)args;(void)argc; return make_num(GetMouseY()); }

static Value native_audio_loadsound(Value *args,int argc){
    Value path = arg(args,argc,0);
    if(path.type!=V_STR || g_sound_count>=MAX_SOUNDS) return make_num(-1);
    Sound s = LoadSound(path.as.s);
    g_sounds[g_sound_count]=s;
    return make_num(g_sound_count++);
}
static Value native_audio_play(Value *args,int argc){
    int id = (int)tonum(arg(args,argc,0),0);
    if(id<0||id>=g_sound_count) return make_nil();
    PlaySound(g_sounds[id]);
    return make_nil();
}
static Value native_audio_loadmusic(Value *args,int argc){
    Value path = arg(args,argc,0);
    if(path.type!=V_STR || g_music_count>=MAX_SOUNDS) return make_num(-1);
    Music m = LoadMusicStream(path.as.s);
    g_musics[g_music_count]=m;
    return make_num(g_music_count++);
}
static Value native_audio_playmusic(Value *args,int argc){
    int id = (int)tonum(arg(args,argc,0),0);
    if(id<0||id>=g_music_count) return make_nil();
    PlayMusicStream(g_musics[id]);
    return make_nil();
}
static Value native_audio_updatemusic(Value *args,int argc){
    int id = (int)tonum(arg(args,argc,0),0);
    if(id<0||id>=g_music_count) return make_nil();
    UpdateMusicStream(g_musics[id]);
    return make_nil();
}

#define MAX_VIDEOS 32
typedef struct {
    FILE *f;
    int used;
    int width, height, frameCount;
    float fps;
    long dataStart;
    long *offsets;
    unsigned int *sizes;
    int rawFrameSize;
    unsigned char *rawBuf;
    unsigned char *compBuf;
    Texture2D tex;
    int currentFrame;
    float accumulator;
    int playing;
    int finished;
    int loop;
} LVideo;
static LVideo g_videos[MAX_VIDEOS];

static unsigned int read_u32(FILE *f){
    unsigned char b[4];
    if(fread(b,1,4,f)!=4) return 0;
    return (unsigned int)b[0] | ((unsigned int)b[1]<<8) | ((unsigned int)b[2]<<16) | ((unsigned int)b[3]<<24);
}
static float read_f32(FILE *f){
    unsigned int u = read_u32(f);
    float r; memcpy(&r,&u,4); return r;
}

static void lvideo_decode_frame(LVideo *v, unsigned char *comp, unsigned int compSize){
    unsigned int ci=0, ri=0;
    while(ci + 3 < compSize && ri + 3 <= (unsigned int)v->rawFrameSize){
        unsigned char count = comp[ci++];
        unsigned char r = comp[ci++];
        unsigned char g = comp[ci++];
        unsigned char b = comp[ci++];
        for(int k=0;k<count && ri + 3 <= (unsigned int)v->rawFrameSize; k++){
            v->rawBuf[ri++] = r;
            v->rawBuf[ri++] = g;
            v->rawBuf[ri++] = b;
        }
    }
}

static int lvideo_load_frame(LVideo *v, int frameIdx){
    if(frameIdx<0 || frameIdx>=v->frameCount) return 0;
    unsigned int sz = v->sizes[frameIdx];
    if(fseek(v->f, v->dataStart + v->offsets[frameIdx], SEEK_SET)!=0) return 0;
    if(fread(v->compBuf,1,sz,v->f)!=sz) return 0;
    lvideo_decode_frame(v, v->compBuf, sz);
    UpdateTexture(v->tex, v->rawBuf);
    v->currentFrame = frameIdx;
    return 1;
}

static Value native_video_load(Value *args,int argc){
    Value path = arg(args,argc,0);
    if(path.type!=V_STR) return make_num(-1);
    int slot=-1;
    for(int i=0;i<MAX_VIDEOS;i++) if(!g_videos[i].used){ slot=i; break; }
    if(slot<0) return make_num(-1);

    FILE *f = fopen(path.as.s,"rb");
    if(!f) return make_num(-1);
    char magic[4];
    if(fread(magic,1,4,f)!=4 || memcmp(magic,"LVID",4)!=0){ fclose(f); return make_num(-1); }

    LVideo *v = &g_videos[slot];
    memset(v,0,sizeof(LVideo));
    v->width = (int)read_u32(f);
    v->height = (int)read_u32(f);
    v->frameCount = (int)read_u32(f);
    v->fps = read_f32(f);

    v->sizes = xmalloc(sizeof(unsigned int)*v->frameCount);
    v->offsets = xmalloc(sizeof(long)*v->frameCount);
    long acc = 0;
    for(int i=0;i<v->frameCount;i++){
        v->sizes[i] = read_u32(f);
        v->offsets[i] = acc;
        acc += v->sizes[i];
    }
    v->dataStart = ftell(f);
    v->f = f;
    v->rawFrameSize = v->width * v->height * 3;
    v->rawBuf = xmalloc(v->rawFrameSize);
    memset(v->rawBuf, 0, v->rawFrameSize);
    v->compBuf = xmalloc((size_t)v->rawFrameSize*2 + 16);

    Image img = GenImageColor(v->width, v->height, BLACK);
    ImageFormat(&img, PIXELFORMAT_UNCOMPRESSED_R8G8B8);
    v->tex = LoadTextureFromImage(img);
    UnloadImage(img);

    v->currentFrame = -1;
    v->playing = 0;
    v->finished = 0;
    v->loop = 1;
    v->used = 1;

    lvideo_load_frame(v, 0);

    return make_num(slot);
}

static LVideo *get_video(Value *args,int argc){
    int id = (int)tonum(arg(args,argc,0),0);
    if(id<0||id>=MAX_VIDEOS||!g_videos[id].used) return NULL;
    return &g_videos[id];
}

static Value native_video_play(Value *args,int argc){
    LVideo *v = get_video(args,argc);
    if(!v) return make_nil();
    v->playing = 1;
    if(v->finished){ v->finished=0; lvideo_load_frame(v,0); v->accumulator=0; }
    return make_nil();
}
static Value native_video_pause(Value *args,int argc){
    LVideo *v = get_video(args,argc);
    if(v) v->playing = 0;
    return make_nil();
}
static Value native_video_stop(Value *args,int argc){
    LVideo *v = get_video(args,argc);
    if(v){
        v->playing = 0;
        v->finished = 0;
        v->accumulator = 0;
        lvideo_load_frame(v, 0);
    }
    return make_nil();
}
static Value native_video_update(Value *args,int argc){
    LVideo *v = get_video(args,argc);
    if(!v) return make_nil();
    double dt = tonum(arg(args,argc,1),0);
    if(!v->playing || v->finished) return make_nil();
    float frameDur = v->fps > 0 ? 1.0f/v->fps : 1.0f/24.0f;
    v->accumulator += (float)dt;
    int guard = 0;
    while(v->accumulator >= frameDur && guard < 8){
        v->accumulator -= frameDur;
        int next = v->currentFrame + 1;
        if(next >= v->frameCount){
            if(v->loop){
                next = 0;
            } else {
                v->finished = 1;
                v->playing = 0;
                break;
            }
        }
        lvideo_load_frame(v, next);
        guard++;
    }
    return make_nil();
}
static Value native_video_draw(Value *args,int argc){
    LVideo *v = get_video(args,argc);
    if(!v) return make_nil();
    double x=tonum(arg(args,argc,1),0), y=tonum(arg(args,argc,2),0);
    double w=argc>3? tonum(args[3],0) : v->width;
    double h=argc>4? tonum(args[4],0) : v->height;
    Rectangle src = { 0, 0, (float)v->width, (float)v->height };
    Rectangle dst = { (float)x, (float)y, (float)w, (float)h };
    DrawTexturePro(v->tex, src, dst, (Vector2){0,0}, 0.0f, WHITE);
    return make_nil();
}
static Value native_video_seek(Value *args,int argc){
    LVideo *v = get_video(args,argc);
    if(!v) return make_nil();
    double seconds = tonum(arg(args,argc,1),0);
    int frame = (int)(seconds * v->fps);
    if(frame<0) frame=0;
    if(frame>=v->frameCount) frame=v->frameCount-1;
    lvideo_load_frame(v, frame);
    v->accumulator = 0;
    v->finished = 0;
    return make_nil();
}
static Value native_video_isfinished(Value *args,int argc){
    LVideo *v = get_video(args,argc);
    if(!v) return make_bool(1);
    return make_bool(v->finished);
}
static Value native_video_setloop(Value *args,int argc){
    LVideo *v = get_video(args,argc);
    if(!v) return make_nil();
    Value b = arg(args,argc,1);
    v->loop = truthy(b);
    return make_nil();
}
static Value native_video_duration(Value *args,int argc){
    LVideo *v = get_video(args,argc);
    if(!v || v->fps<=0) return make_num(0);
    return make_num(v->frameCount / v->fps);
}

static Camera3D g_camera;
static int g_camera_ready = 0;

static void ensure_camera(void){
    if(!g_camera_ready){
        g_camera.position = (Vector3){ 10.0f, 10.0f, 10.0f };
        g_camera.target = (Vector3){ 0.0f, 0.0f, 0.0f };
        g_camera.up = (Vector3){ 0.0f, 1.0f, 0.0f };
        g_camera.fovy = 45.0f;
        g_camera.projection = CAMERA_PERSPECTIVE;
        g_camera_ready = 1;
    }
}

static Value native_d3_camera(Value *args,int argc){
    ensure_camera();
    g_camera.position.x = (float)tonum(arg(args,argc,0),0);
    g_camera.position.y = (float)tonum(arg(args,argc,1),0);
    g_camera.position.z = (float)tonum(arg(args,argc,2),0);
    g_camera.target.x = (float)tonum(arg(args,argc,3),0);
    g_camera.target.y = (float)tonum(arg(args,argc,4),0);
    g_camera.target.z = (float)tonum(arg(args,argc,5),0);
    g_camera.fovy = argc>6 ? (float)tonum(args[6],0) : 45.0f;
    return make_nil();
}
static Value native_d3_setpos(Value *args,int argc){
    ensure_camera();
    g_camera.position.x = (float)tonum(arg(args,argc,0),0);
    g_camera.position.y = (float)tonum(arg(args,argc,1),0);
    g_camera.position.z = (float)tonum(arg(args,argc,2),0);
    return make_nil();
}
static Value native_d3_settarget(Value *args,int argc){
    ensure_camera();
    g_camera.target.x = (float)tonum(arg(args,argc,0),0);
    g_camera.target.y = (float)tonum(arg(args,argc,1),0);
    g_camera.target.z = (float)tonum(arg(args,argc,2),0);
    return make_nil();
}
static Value native_d3_orbit(Value *args,int argc){
    ensure_camera();
    float dx = (float)tonum(arg(args,argc,0),0);
    float dy = (float)tonum(arg(args,argc,1),0);
    UpdateCameraPro(&g_camera,
        (Vector3){0,0,0},
        (Vector3){dx, dy, 0},
        0.0f);
    return make_nil();
}
static Value native_d3_begin(Value *args,int argc){
    (void)args;(void)argc;
    ensure_camera();
    BeginMode3D(g_camera);
    return make_nil();
}
static Value native_d3_finish(Value *args,int argc){ (void)args;(void)argc; EndMode3D(); return make_nil(); }

static Value native_d3_cube(Value *args,int argc){
    double x=tonum(arg(args,argc,0),0), y=tonum(arg(args,argc,1),0), z=tonum(arg(args,argc,2),0);
    double w=tonum(arg(args,argc,3),0), h=tonum(arg(args,argc,4),0), d=tonum(arg(args,argc,5),0);
    Color c = color_from_args(args,argc,6);
    DrawCube((Vector3){(float)x,(float)y,(float)z},(float)w,(float)h,(float)d,c);
    return make_nil();
}
static Value native_d3_cubewires(Value *args,int argc){
    double x=tonum(arg(args,argc,0),0), y=tonum(arg(args,argc,1),0), z=tonum(arg(args,argc,2),0);
    double w=tonum(arg(args,argc,3),0), h=tonum(arg(args,argc,4),0), d=tonum(arg(args,argc,5),0);
    Color c = color_from_args(args,argc,6);
    DrawCubeWires((Vector3){(float)x,(float)y,(float)z},(float)w,(float)h,(float)d,c);
    return make_nil();
}
static Value native_d3_sphere(Value *args,int argc){
    double x=tonum(arg(args,argc,0),0), y=tonum(arg(args,argc,1),0), z=tonum(arg(args,argc,2),0);
    double r=tonum(arg(args,argc,3),0);
    Color c = color_from_args(args,argc,4);
    DrawSphere((Vector3){(float)x,(float)y,(float)z},(float)r,c);
    return make_nil();
}
static Value native_d3_plane(Value *args,int argc){
    double x=tonum(arg(args,argc,0),0), y=tonum(arg(args,argc,1),0), z=tonum(arg(args,argc,2),0);
    double w=tonum(arg(args,argc,3),0), d=tonum(arg(args,argc,4),0);
    Color c = color_from_args(args,argc,5);
    DrawPlane((Vector3){(float)x,(float)y,(float)z},(Vector2){(float)w,(float)d},c);
    return make_nil();
}
static Value native_d3_line(Value *args,int argc){
    double x1=tonum(arg(args,argc,0),0), y1=tonum(arg(args,argc,1),0), z1=tonum(arg(args,argc,2),0);
    double x2=tonum(arg(args,argc,3),0), y2=tonum(arg(args,argc,4),0), z2=tonum(arg(args,argc,5),0);
    Color c = color_from_args(args,argc,6);
    DrawLine3D((Vector3){(float)x1,(float)y1,(float)z1},(Vector3){(float)x2,(float)y2,(float)z2},c);
    return make_nil();
}
static Value native_d3_grid(Value *args,int argc){
    double slices = argc>0 ? tonum(args[0],0) : 20;
    double spacing = argc>1 ? tonum(args[1],0) : 1.0;
    DrawGrid((int)slices,(float)spacing);
    return make_nil();
}
static void register_graphics(Env *g){
    Table *win = table_new();
    table_set(win,"open", make_native(native_window_open));
    table_set(win,"close", make_native(native_window_close));
    table_set(win,"shouldClose", make_native(native_window_shouldclose));
    table_set(win,"setTitle", make_native(native_window_settitle));
    env_define(g,"window", make_table(win));

    Table *draw = table_new();
    table_set(draw,"begin", make_native(native_draw_begin));
    table_set(draw,"finish", make_native(native_draw_end));
    table_set(draw,"clear", make_native(native_draw_clear));
    table_set(draw,"rect", make_native(native_draw_rect));
    table_set(draw,"circle", make_native(native_draw_circle));
    table_set(draw,"line", make_native(native_draw_line));
    table_set(draw,"text", make_native(native_draw_text));
    table_set(draw,"fps", make_native(native_draw_fps));
    table_set(draw,"screenshot", make_native(native_draw_screenshot));
    env_define(g,"draw", make_table(draw));

    Table *image = table_new();
    table_set(image,"load", make_native(native_image_load));
    table_set(image,"draw", make_native(native_image_draw));
    table_set(image,"width", make_native(native_image_width));
    table_set(image,"height", make_native(native_image_height));
    env_define(g,"image", make_table(image));

    Table *input = table_new();
    table_set(input,"key", make_native(native_input_key));
    table_set(input,"keyPressed", make_native(native_input_keypressed));
    table_set(input,"mouseDown", make_native(native_input_mousedown));
    table_set(input,"mouseX", make_native(native_input_mousex));
    table_set(input,"mouseY", make_native(native_input_mousey));
    env_define(g,"input", make_table(input));

    Table *audio = table_new();
    table_set(audio,"loadSound", make_native(native_audio_loadsound));
    table_set(audio,"play", make_native(native_audio_play));
    table_set(audio,"loadMusic", make_native(native_audio_loadmusic));
    table_set(audio,"playMusic", make_native(native_audio_playmusic));
    table_set(audio,"updateMusic", make_native(native_audio_updatemusic));
    env_define(g,"audio", make_table(audio));

    Table *time = table_new();
    table_set(time,"dt", make_native(native_time_dt));
    table_set(time,"now", make_native(native_time_now));
    env_define(g,"time", make_table(time));

    Table *video = table_new();
    table_set(video,"load", make_native(native_video_load));
    table_set(video,"play", make_native(native_video_play));
    table_set(video,"pause", make_native(native_video_pause));
    table_set(video,"stop", make_native(native_video_stop));
    table_set(video,"update", make_native(native_video_update));
    table_set(video,"draw", make_native(native_video_draw));
    table_set(video,"seek", make_native(native_video_seek));
    table_set(video,"isFinished", make_native(native_video_isfinished));
    table_set(video,"setLoop", make_native(native_video_setloop));
    table_set(video,"duration", make_native(native_video_duration));
    env_define(g,"video", make_table(video));

    Table *d3 = table_new();
    table_set(d3,"camera", make_native(native_d3_camera));
    table_set(d3,"setPos", make_native(native_d3_setpos));
    table_set(d3,"setTarget", make_native(native_d3_settarget));
    table_set(d3,"orbit", make_native(native_d3_orbit));
    table_set(d3,"begin", make_native(native_d3_begin));
    table_set(d3,"finish", make_native(native_d3_finish));
    table_set(d3,"cube", make_native(native_d3_cube));
    table_set(d3,"cubeWires", make_native(native_d3_cubewires));
    table_set(d3,"sphere", make_native(native_d3_sphere));
    table_set(d3,"plane", make_native(native_d3_plane));
    table_set(d3,"line", make_native(native_d3_line));
    table_set(d3,"grid", make_native(native_d3_grid));
    env_define(g,"d3", make_table(d3));
}
#endif

static char *read_file(const char *path){
    FILE *f = fopen(path,"rb");
    if(!f){ fprintf(stderr,"light: cannot open file '%s'\n",path); exit(1); }
    fseek(f,0,SEEK_END);
    long sz = ftell(f);
    fseek(f,0,SEEK_SET);
    char *buf = xmalloc(sz+1);
    size_t got = fread(buf,1,sz,f);
    buf[got]=0;
    fclose(f);
    return buf;
}

static void print_usage(void){
    printf("light %s\n", LIGHT_VERSION);
    printf("usage: light <file.light>\n");
}

int main(int argc, char **argv){
    if(argc<2){
        print_usage();
        fflush(stdout);
        return 1;
    }
    if(strcmp(argv[1],"--version")==0 || strcmp(argv[1],"-v")==0){
        printf("light %s\n", LIGHT_VERSION);
        fflush(stdout);
        return 0;
    }
    if(strcmp(argv[1],"--help")==0 || strcmp(argv[1],"-h")==0){
        print_usage();
        fflush(stdout);
        return 0;
    }
    const char *path = argv[1];
    char *src = read_file(path);

    char *pathcopy = xstrdup(path);
    char *slash = strrchr(pathcopy, '/');
    char *bslash = strrchr(pathcopy, '\\');
    if(bslash && (!slash || bslash > slash)) slash = bslash;
    if(slash){
        *slash = 0;
        if(chdir(pathcopy) != 0){
            fprintf(stderr, "light: warning: could not enter script directory '%s'\n", pathcopy);
        }
    }
    free(pathcopy);

    StatList *program = parse_program(src);

    g_globals = env_new(NULL);
    register_natives(g_globals);
#ifdef LIGHT_GRAPHICS
    register_graphics(g_globals);
#endif

    Table *argt = table_new();
    for(int i=2;i<argc;i++) table_set(argt, numkey(i-1), make_str(argv[i]));
    env_define(g_globals,"arg", make_table(argt));

    g_flow = FLOW_NONE;
    exec_block(program, g_globals);

    return 0;
}