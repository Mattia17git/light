import re
from enum import Enum, auto
from dataclasses import dataclass
from typing import List, Optional


class TokenType(Enum):
    NUMBER    = auto()
    STRING    = auto()
    BOOL      = auto()
    NIL       = auto()

    IDENT     = auto()
    LET       = auto()
    FN        = auto()
    IF        = auto()
    ELIF      = auto()
    ELSE      = auto()
    WHILE     = auto()
    FOR       = auto()
    IN        = auto()
    RETURN    = auto()
    BREAK     = auto()
    CONTINUE  = auto()
    DO        = auto()
    END       = auto()
    AND       = auto()
    OR        = auto()
    NOT       = auto()
    CLASS     = auto()
    NEW       = auto()
    SELF      = auto()
    IMPORT    = auto()
    PRINT     = auto()

    TYPE_INT    = auto()
    TYPE_FLOAT  = auto()
    TYPE_STRING = auto()
    TYPE_BOOL   = auto()
    TYPE_ANY    = auto()

    PLUS      = auto()
    MINUS     = auto()
    STAR      = auto()
    SLASH     = auto()
    PERCENT   = auto()
    CARET     = auto()
    CONCAT    = auto()
    EQ        = auto()
    NEQ       = auto()
    LT        = auto()
    LTE       = auto()
    GT        = auto()
    GTE       = auto()
    ASSIGN    = auto()
    COLON     = auto()
    ARROW     = auto()
    HASH      = auto()

    LPAREN    = auto()
    RPAREN    = auto()
    LBRACE    = auto()
    RBRACE    = auto()
    LBRACKET  = auto()
    RBRACKET  = auto()
    COMMA     = auto()
    DOT       = auto()

    NEWLINE   = auto()
    EOF       = auto()


KEYWORDS = {
    "let":       TokenType.LET,
    "fn":        TokenType.FN,
    "if":        TokenType.IF,
    "elif":      TokenType.ELIF,
    "else":      TokenType.ELSE,
    "while":     TokenType.WHILE,
    "for":       TokenType.FOR,
    "in":        TokenType.IN,
    "return":    TokenType.RETURN,
    "break":     TokenType.BREAK,
    "continue":  TokenType.CONTINUE,
    "do":        TokenType.DO,
    "end":       TokenType.END,
    "and":       TokenType.AND,
    "or":        TokenType.OR,
    "not":       TokenType.NOT,
    "true":      TokenType.BOOL,
    "false":     TokenType.BOOL,
    "nil":       TokenType.NIL,
    "class":     TokenType.CLASS,
    "new":       TokenType.NEW,
    "self":      TokenType.SELF,
    "import":    TokenType.IMPORT,
    "print":     TokenType.PRINT,
    "int":       TokenType.TYPE_INT,
    "float":     TokenType.TYPE_FLOAT,
    "string":    TokenType.TYPE_STRING,
    "bool":      TokenType.TYPE_BOOL,
    "any":       TokenType.TYPE_ANY,
}


@dataclass
class Token:
    type: TokenType
    value: object
    line: int
    col: int

    def __repr__(self):
        return f"Token({self.type.name}, {self.value!r}, {self.line}:{self.col})"


class LexerError(Exception):
    def __init__(self, message: str, line: int, col: int):
        super().__init__(f"[line {line}:{col}] LexerError: {message}")
        self.line = line
        self.col = col


class Lexer:
    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.col = 1
        self.tokens: List[Token] = []

    def error(self, msg: str):
        raise LexerError(msg, self.line, self.col)

    def peek(self, offset=0) -> Optional[str]:
        idx = self.pos + offset
        return self.source[idx] if idx < len(self.source) else None

    def advance(self) -> str:
        ch = self.source[self.pos]
        self.pos += 1
        if ch == '\n':
            self.line += 1
            self.col = 1
        else:
            self.col += 1
        return ch

    def match(self, expected: str) -> bool:
        if self.peek() == expected:
            self.advance()
            return True
        return False

    def add(self, ttype: TokenType, value=None, line=None, col=None):
        self.tokens.append(Token(ttype, value, line or self.line, col or self.col))

    def skip_whitespace_and_comments(self):
        while self.pos < len(self.source):
            ch = self.peek()
            if ch in (' ', '\t', '\r'):
                self.advance()
            elif ch == '-' and self.peek(1) == '-':
                while self.peek() and self.peek() != '\n':
                    self.advance()
            else:
                break

    def read_string(self, quote: str) -> str:
        parts = []
        while True:
            ch = self.peek()
            if ch is None:
                self.error("Unterminated string")
            if ch == quote:
                self.advance()
                break
            if ch == '\\':
                self.advance()
                break
            if ch == '\\':
                self.advance()
                esc = self.advance()
                parts.append({'n': '\n', 't': '\t', 'r': '\r', '\\': '\\',
                              '"': '"', "'": "'"}.get(esc, esc))
            else:
                parts.append(self.advance())
        return ''.join(parts)

    def read_number(self, first: str) -> Token:
        line, col = self.line, self.col
        num = first
        is_float = False
        while self.peek() and self.peek().isdigit():
            num += self.advance()
        if self.peek() == '.' and self.peek(1) and self.peek(1).isdigit():
            is_float = True
            num += self.advance()
            while self.peek() and self.peek().isdigit():
                num += self.advance()
        value = float(num) if is_float else int(num)
        return Token(TokenType.NUMBER, value, line, col)

    def tokenize(self) -> List[Token]:
        while self.pos < len(self.source):
            self.skip_whitespace_and_comments()
            if self.pos >= len(self.source):
                break

            ch = self.peek()
            line, col = self.line, self.col

            if ch == '\n':
                self.advance()
                self.add(TokenType.NEWLINE, '\n', line, col)
                continue

            self.advance()

            if ch in ('"', "'"):
                s = self.read_string(ch)
                self.add(TokenType.STRING, s, line, col)

            elif ch.isdigit():
                tok = self.read_number(ch)
                self.tokens.append(tok)

            elif ch.isalpha() or ch == '_':
                ident = ch
                while self.peek() and (self.peek().isalnum() or self.peek() == '_'):
                    ident += self.advance()
                ttype = KEYWORDS.get(ident, TokenType.IDENT)
                value = ident if ttype == TokenType.IDENT else (
                    True if ident == 'true' else
                    False if ident == 'false' else
                    ident
                )
                self.add(ttype, value, line, col)

            elif ch == '+': self.add(TokenType.PLUS, '+', line, col)
            elif ch == '-':
                if self.match('>'):
                    self.add(TokenType.ARROW, '->', line, col)
                else:
                    self.add(TokenType.MINUS, '-', line, col)
            elif ch == '*': self.add(TokenType.STAR, '*', line, col)
            elif ch == '^': self.add(TokenType.CARET, '^', line, col)
            elif ch == '%': self.add(TokenType.PERCENT, '%', line, col)
            elif ch == '#': self.add(TokenType.HASH, '#', line, col)
            elif ch == ',': self.add(TokenType.COMMA, ',', line, col)
            elif ch == '(': self.add(TokenType.LPAREN, '(', line, col)
            elif ch == ')': self.add(TokenType.RPAREN, ')', line, col)
            elif ch == '{': self.add(TokenType.LBRACE, '{', line, col)
            elif ch == '}': self.add(TokenType.RBRACE, '}', line, col)
            elif ch == '[': self.add(TokenType.LBRACKET, '[', line, col)
            elif ch == ']': self.add(TokenType.RBRACKET, ']', line, col)
            elif ch == '.':
                if self.match('.'):
                    self.add(TokenType.CONCAT, '..', line, col)
                else:
                    self.add(TokenType.DOT, '.', line, col)
            elif ch == '/':
                self.add(TokenType.SLASH, '/', line, col)
            elif ch == '=':
                if self.match('='):
                    self.add(TokenType.EQ, '==', line, col)
                else:
                    self.add(TokenType.ASSIGN, '=', line, col)
            elif ch == '~':
                if self.match('='):
                    self.add(TokenType.NEQ, '~=', line, col)
                else:
                    self.error(f"Unexpected character '~'")
            elif ch == '!':
                if self.match('='):
                    self.add(TokenType.NEQ, '!=', line, col)
                else:
                    self.error(f"Unexpected character '!'")
            elif ch == '<':
                if self.match('='):
                    self.add(TokenType.LTE, '<=', line, col)
                else:
                    self.add(TokenType.LT, '<', line, col)
            elif ch == '>':
                if self.match('='):
                    self.add(TokenType.GTE, '>=', line, col)
                else:
                    self.add(TokenType.GT, '>', line, col)
            elif ch == ':':
                self.add(TokenType.COLON, ':', line, col)
            else:
                self.error(f"Unexpected character '{ch}'")

        self.add(TokenType.EOF, None, self.line, self.col)
        return self.tokens