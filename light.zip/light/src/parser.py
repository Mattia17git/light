from typing import List, Optional, Any
from .lexer import Token, TokenType
from .ast_nodes import *


class ParseError(Exception):
    def __init__(self, message: str, line: int):
        super().__init__(f"[line {line}] ParseError: {message}")
        self.line = line


class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0

    def peek(self, offset=0) -> Token:
        idx = self.pos + offset
        if idx < len(self.tokens):
            return self.tokens[idx]
        return self.tokens[-1]

    def check(self, *types: TokenType) -> bool:
        return self.peek().type in types

    def advance(self) -> Token:
        t = self.tokens[self.pos]
        if t.type != TokenType.EOF:
            self.pos += 1
        return t

    def match(self, *types: TokenType) -> Optional[Token]:
        if self.peek().type in types:
            return self.advance()
        return None

    def expect(self, ttype: TokenType, msg: str = "") -> Token:
        if self.peek().type == ttype:
            return self.advance()
        t = self.peek()
        raise ParseError(msg or f"Expected {ttype.name}, got {t.type.name} ({t.value!r})", t.line)

    def skip_newlines(self):
        while self.peek().type == TokenType.NEWLINE:
            self.advance()

    def error(self, msg: str):
        raise ParseError(msg, self.peek().line)

    def set_line(self, node: Node, line: int) -> Node:
        node.line = line
        return node

    def parse_type(self) -> TypeAnnotation:
        type_tokens = {
            TokenType.TYPE_INT, TokenType.TYPE_FLOAT,
            TokenType.TYPE_STRING, TokenType.TYPE_BOOL,
            TokenType.TYPE_ANY, TokenType.IDENT
        }
        t = self.peek()
        if t.type not in type_tokens:
            self.error(f"Expected type name, got {t.value!r}")
        self.advance()
        name = str(t.value)
        nullable = False
        return TypeAnnotation(name=name, nullable=nullable)

    def parse(self) -> Program:
        stmts = []
        self.skip_newlines()
        while not self.check(TokenType.EOF):
            stmts.append(self.parse_stmt())
            self.skip_newlines()
        return Program(stmts=stmts)

    def parse_stmt(self) -> Any:
        self.skip_newlines()
        t = self.peek()

        if t.type == TokenType.LET:
            return self.parse_var_decl()
        if t.type == TokenType.FN:
            return self.parse_fn_decl()
        if t.type == TokenType.CLASS:
            return self.parse_class_decl()
        if t.type == TokenType.IF:
            return self.parse_if()
        if t.type == TokenType.WHILE:
            return self.parse_while()
        if t.type == TokenType.FOR:
            return self.parse_for()
        if t.type == TokenType.RETURN:
            return self.parse_return()
        if t.type == TokenType.BREAK:
            self.advance()
            return self.set_line(BreakStmt(), t.line)
        if t.type == TokenType.CONTINUE:
            self.advance()
            return self.set_line(ContinueStmt(), t.line)
        if t.type == TokenType.PRINT:
            return self.parse_print()
        if t.type == TokenType.IMPORT:
            return self.parse_import()

        return self.parse_assign_or_expr()

    def parse_var_decl(self) -> VarDecl:
        line = self.peek().line
        self.expect(TokenType.LET)
        name = self.expect(TokenType.IDENT, "Expected variable name after 'let'").value
        type_ann = None
        if self.match(TokenType.COLON):
            type_ann = self.parse_type()
        value = None
        if self.match(TokenType.ASSIGN):
            value = self.parse_expr()
        return self.set_line(VarDecl(name=name, type_ann=type_ann, value=value), line)

    def parse_fn_decl(self) -> FnDecl:
        line = self.peek().line
        self.expect(TokenType.FN)
        name = self.expect(TokenType.IDENT, "Expected function name after 'fn'").value
        self.expect(TokenType.LPAREN, "Expected '(' after function name")
        params = self.parse_params()
        self.expect(TokenType.RPAREN, "Expected ')' after parameters")
        return_type = None
        if self.match(TokenType.ARROW):
            return_type = self.parse_type()
        body = self.parse_block()
        return self.set_line(FnDecl(name=name, params=params, return_type=return_type, body=body), line)

    def parse_params(self) -> List[Param]:
        params = []
        if self.check(TokenType.RPAREN):
            return params
        while True:
            line = self.peek().line
            name = self.expect(TokenType.IDENT, "Expected parameter name").value
            type_ann = None
            if self.match(TokenType.COLON):
                type_ann = self.parse_type()
            params.append(self.set_line(Param(name=name, type_ann=type_ann), line))
            if not self.match(TokenType.COMMA):
                break
        return params

    def parse_class_decl(self) -> ClassDecl:
        line = self.peek().line
        self.expect(TokenType.CLASS)
        name = self.expect(TokenType.IDENT, "Expected class name after 'class'").value
        self.skip_newlines()
        fields = []
        methods = []
        init_method = None
        while not self.check(TokenType.END, TokenType.EOF):
            self.skip_newlines()
            if self.check(TokenType.END):
                break
            t = self.peek()
            if t.type == TokenType.FN:
                method = self.parse_method()
                if method.name == "init":
                    init_method = method
                else:
                    methods.append(method)
            elif t.type == TokenType.LET:
                self.advance()
                fname = self.expect(TokenType.IDENT).value
                ftype = None
                fdefault = None
                if self.match(TokenType.COLON):
                    ftype = self.parse_type()
                if self.match(TokenType.ASSIGN):
                    fdefault = self.parse_expr()
                fields.append(self.set_line(FieldDef(name=fname, type_ann=ftype, default=fdefault), t.line))
            else:
                self.error(f"Unexpected token in class body: {t.value!r}")
            self.skip_newlines()
        self.expect(TokenType.END, "Expected 'end' after class body")
        return self.set_line(ClassDecl(name=name, fields=fields, methods=methods, init=init_method), line)

    def parse_method(self) -> MethodDef:
        line = self.peek().line
        self.expect(TokenType.FN)
        name = self.expect(TokenType.IDENT, "Expected method name").value
        self.expect(TokenType.LPAREN)
        params = []
        if self.check(TokenType.SELF):
            self.advance()
            if self.match(TokenType.COMMA):
                params = self.parse_params()
        else:
            params = self.parse_params()
        self.expect(TokenType.RPAREN)
        return_type = None
        if self.match(TokenType.ARROW):
            return_type = self.parse_type()
        body = self.parse_block()
        return self.set_line(MethodDef(name=name, params=params, return_type=return_type, body=body), line)

    def parse_if(self) -> IfStmt:
        line = self.peek().line
        self.expect(TokenType.IF)
        branches = []
        cond = self.parse_expr()
        body = self.parse_block_until(TokenType.ELIF, TokenType.ELSE, TokenType.END)
        branches.append((cond, body))
        while self.check(TokenType.ELIF):
            self.advance()
            cond = self.parse_expr()
            body = self.parse_block_until(TokenType.ELIF, TokenType.ELSE, TokenType.END)
            branches.append((cond, body))
        else_block = None
        if self.match(TokenType.ELSE):
            else_block = self.parse_block_until(TokenType.END)
        self.expect(TokenType.END, "Expected 'end' after if/else")
        return self.set_line(IfStmt(branches=branches, else_block=else_block), line)

    def parse_while(self) -> WhileStmt:
        line = self.peek().line
        self.expect(TokenType.WHILE)
        cond = self.parse_expr()
        body = self.parse_block()
        return self.set_line(WhileStmt(condition=cond, body=body), line)

    def parse_for(self) -> Any:
        line = self.peek().line
        self.expect(TokenType.FOR)
        var = self.expect(TokenType.IDENT, "Expected variable after 'for'").value
        if self.match(TokenType.ASSIGN):
            start = self.parse_expr()
            self.expect(TokenType.COMMA, "Expected ',' after start in numeric for")
            stop = self.parse_expr()
            step = None
            if self.match(TokenType.COMMA):
                step = self.parse_expr()
            body = self.parse_block()
            return self.set_line(ForNumeric(var=var, start=start, stop=stop, step=step, body=body), line)
        else:
            self.expect(TokenType.IN, "Expected 'in' or '=' after loop variable")
            iterable = self.parse_expr()
            body = self.parse_block()
            return self.set_line(ForIn(var=var, iterable=iterable, body=body), line)

    def parse_return(self) -> ReturnStmt:
        line = self.peek().line
        self.expect(TokenType.RETURN)
        value = None
        if not self.check(TokenType.NEWLINE, TokenType.EOF, TokenType.END):
            value = self.parse_expr()
        return self.set_line(ReturnStmt(value=value), line)

    def parse_print(self) -> PrintStmt:
        line = self.peek().line
        self.expect(TokenType.PRINT)
        self.expect(TokenType.LPAREN, "Expected '(' after 'print'")
        values = []
        if not self.check(TokenType.RPAREN):
            values.append(self.parse_expr())
            while self.match(TokenType.COMMA):
                values.append(self.parse_expr())
        self.expect(TokenType.RPAREN)
        return self.set_line(PrintStmt(values=values), line)

    def parse_import(self) -> ImportStmt:
        line = self.peek().line
        self.expect(TokenType.IMPORT)
        module = self.expect(TokenType.IDENT, "Expected module name after 'import'").value
        alias = None
        if self.check(TokenType.IDENT) and self.peek().value == "as":
            self.advance()
            alias = self.expect(TokenType.IDENT).value
        return self.set_line(ImportStmt(module=module, alias=alias), line)

    def parse_assign_or_expr(self) -> Any:
        line = self.peek().line
        expr = self.parse_expr()
        if self.match(TokenType.ASSIGN):
            value = self.parse_expr()
            if isinstance(expr, (Ident, GetField, Index)):
                return self.set_line(Assign(target=expr, value=value), line)
            self.error("Invalid assignment target")
        return self.set_line(ExprStmt(expr=expr), line)

    def parse_block(self) -> Block:
        block = self.parse_block_until(TokenType.END)
        self.expect(TokenType.END, "Expected 'end' to close block")
        return block

    def parse_block_until(self, *stop_types: TokenType) -> Block:
        stmts = []
        self.skip_newlines()
        while not self.check(*stop_types) and not self.check(TokenType.EOF):
            stmts.append(self.parse_stmt())
            self.skip_newlines()
        return Block(stmts=stmts)

    def parse_expr(self) -> Any:
        return self.parse_or()

    def parse_or(self) -> Any:
        line = self.peek().line
        left = self.parse_and()
        while self.check(TokenType.OR):
            op = self.advance().value
            right = self.parse_and()
            left = self.set_line(BinOp(op='or', left=left, right=right), line)
        return left

    def parse_and(self) -> Any:
        line = self.peek().line
        left = self.parse_not()
        while self.check(TokenType.AND):
            self.advance()
            right = self.parse_not()
            left = self.set_line(BinOp(op='and', left=left, right=right), line)
        return left

    def parse_not(self) -> Any:
        line = self.peek().line
        if self.check(TokenType.NOT):
            self.advance()
            operand = self.parse_not()
            return self.set_line(UnOp(op='not', operand=operand), line)
        return self.parse_comparison()

    def parse_comparison(self) -> Any:
        line = self.peek().line
        left = self.parse_concat()
        ops = {TokenType.EQ, TokenType.NEQ, TokenType.LT,
               TokenType.LTE, TokenType.GT, TokenType.GTE}
        while self.check(*ops):
            op = self.advance().value
            right = self.parse_concat()
            left = self.set_line(BinOp(op=op, left=left, right=right), line)
        return left

    def parse_concat(self) -> Any:
        line = self.peek().line
        left = self.parse_additive()
        while self.check(TokenType.CONCAT):
            self.advance()
            right = self.parse_additive()
            left = self.set_line(Concat(left=left, right=right), line)
        return left

    def parse_additive(self) -> Any:
        line = self.peek().line
        left = self.parse_multiplicative()
        while self.check(TokenType.PLUS, TokenType.MINUS):
            op = self.advance().value
            right = self.parse_multiplicative()
            left = self.set_line(BinOp(op=op, left=left, right=right), line)
        return left

    def parse_multiplicative(self) -> Any:
        line = self.peek().line
        left = self.parse_power()
        while self.check(TokenType.STAR, TokenType.SLASH, TokenType.PERCENT):
            op = self.advance().value
            right = self.parse_power()
            left = self.set_line(BinOp(op=op, left=left, right=right), line)
        return left

    def parse_power(self) -> Any:
        line = self.peek().line
        left = self.parse_unary()
        if self.check(TokenType.CARET):
            self.advance()
            right = self.parse_power()
            return self.set_line(BinOp(op='^', left=left, right=right), line)
        return left

    def parse_unary(self) -> Any:
        line = self.peek().line
        if self.check(TokenType.MINUS):
            self.advance()
            return self.set_line(UnOp(op='-', operand=self.parse_unary()), line)
        if self.check(TokenType.HASH):
            self.advance()
            return self.set_line(LengthOf(operand=self.parse_unary()), line)
        return self.parse_call()

    def parse_call(self) -> Any:
        line = self.peek().line
        expr = self.parse_primary()
        while True:
            if self.check(TokenType.LPAREN):
                self.advance()
                args = []
                if not self.check(TokenType.RPAREN):
                    args.append(self.parse_expr())
                    while self.match(TokenType.COMMA):
                        args.append(self.parse_expr())
                self.expect(TokenType.RPAREN, "Expected ')' after arguments")
                expr = self.set_line(Call(callee=expr, args=args), line)
            elif self.check(TokenType.DOT):
                self.advance()
                field = self.expect(TokenType.IDENT, "Expected field name after '.'").value
                expr = self.set_line(GetField(obj=expr, field=field), line)
            elif self.check(TokenType.LBRACKET):
                self.advance()
                key = self.parse_expr()
                self.expect(TokenType.RBRACKET, "Expected ']'")
                expr = self.set_line(Index(obj=expr, key=key), line)
            else:
                break
        return expr

    def parse_primary(self) -> Any:
        line = self.peek().line
        t = self.peek()

        if t.type == TokenType.NUMBER:
            self.advance()
            return self.set_line(NumberLit(value=t.value), line)

        if t.type == TokenType.STRING:
            self.advance()
            return self.set_line(StringLit(value=t.value), line)

        if t.type == TokenType.BOOL:
            self.advance()
            return self.set_line(BoolLit(value=t.value), line)

        if t.type == TokenType.NIL:
            self.advance()
            return self.set_line(NilLit(), line)

        if t.type == TokenType.SELF:
            self.advance()
            return self.set_line(SelfExpr(), line)

        if t.type == TokenType.IDENT:
            self.advance()
            return self.set_line(Ident(name=t.value), line)

        if t.type == TokenType.NEW:
            self.advance()
            name = self.expect(TokenType.IDENT, "Expected class name after 'new'").value
            self.expect(TokenType.LPAREN)
            args = []
            if not self.check(TokenType.RPAREN):
                args.append(self.parse_expr())
                while self.match(TokenType.COMMA):
                    args.append(self.parse_expr())
            self.expect(TokenType.RPAREN)
            return self.set_line(NewExpr(class_name=name, args=args), line)

        if t.type == TokenType.LPAREN:
            self.advance()
            expr = self.parse_expr()
            self.expect(TokenType.RPAREN, "Expected ')' after expression")
            return expr

        if t.type == TokenType.LBRACKET:
            self.advance()
            elements = []
            self.skip_newlines()
            if not self.check(TokenType.RBRACKET):
                elements.append(self.parse_expr())
                self.skip_newlines()
                while self.match(TokenType.COMMA):
                    self.skip_newlines()
                    if self.check(TokenType.RBRACKET):
                        break
                    elements.append(self.parse_expr())
                    self.skip_newlines()
            self.expect(TokenType.RBRACKET)
            return self.set_line(ListLit(elements=elements), line)

        if t.type == TokenType.LBRACE:
            return self.parse_table()

        self.error(f"Unexpected token: {t.type.name} ({t.value!r})")

    def parse_table(self) -> TableLit:
        line = self.peek().line
        self.expect(TokenType.LBRACE)
        pairs = []
        self.skip_newlines()
        while not self.check(TokenType.RBRACE, TokenType.EOF):
            if self.check(TokenType.IDENT) and self.peek(1).type == TokenType.ASSIGN:
                key = self.set_line(StringLit(value=self.advance().value), self.peek().line)
                self.advance()
                value = self.parse_expr()
            elif self.check(TokenType.LBRACKET):
                self.advance()
                key = self.parse_expr()
                self.expect(TokenType.RBRACKET)
                self.expect(TokenType.ASSIGN)
                value = self.parse_expr()
            else:
                key = None
                value = self.parse_expr()
            pairs.append((key, value))
            self.skip_newlines()
            if not self.match(TokenType.COMMA):
                self.skip_newlines()
                break
            self.skip_newlines()
        self.expect(TokenType.RBRACE, "Expected '}' after table")
        return self.set_line(TableLit(pairs=pairs), line)