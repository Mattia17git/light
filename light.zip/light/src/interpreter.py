from typing import Any, Dict, List, Optional
from .ast_nodes import *


class LightList:
    def __init__(self, elements: list):
        self.elements = elements

    def __repr__(self):
        return "[" + ", ".join(light_repr(e) for e in self.elements) + "]"


class LightTable:
    def __init__(self, pairs: dict = None):
        self.data: dict = pairs or {}

    def __repr__(self):
        pairs = ", ".join(f"{k!r}: {light_repr(v)}" for k, v in self.data.items())
        return "{" + pairs + "}"


class LightFunction:
    def __init__(self, name: str, params: List[Param], body: Block, closure: "Environment", return_type=None):
        self.name = name
        self.params = params
        self.body = body
        self.closure = closure
        self.return_type = return_type

    def __repr__(self):
        return f"<fn {self.name}>"


class LightClass:
    def __init__(self, name: str, fields: List[FieldDef], methods: Dict[str, "LightFunction"], init: Optional["LightFunction"]):
        self.name = name
        self.fields = fields
        self.methods = methods
        self.init = init

    def __repr__(self):
        return f"<class {self.name}>"


class LightInstance:
    def __init__(self, klass: LightClass):
        self.klass = klass
        self.fields: Dict[str, Any] = {}
        for f in klass.fields:
            self.fields[f.name] = None

    def __repr__(self):
        return f"<{self.klass.name} instance>"


def light_repr(value: Any) -> str:
    if value is None:
        return "nil"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float) and value == int(value):
        return str(int(value))
    return str(value)


class ReturnSignal(Exception):
    def __init__(self, value):
        self.value = value


class BreakSignal(Exception):
    pass


class ContinueSignal(Exception):
    pass


class Environment:
    def __init__(self, parent: Optional["Environment"] = None):
        self.vars: Dict[str, Any] = {}
        self.parent = parent

    def get(self, name: str) -> Any:
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name)
        raise RuntimeError(f"Undefined variable '{name}'")

    def set(self, name: str, value: Any):
        if name in self.vars:
            self.vars[name] = value
            return
        if self.parent:
            self.parent.set(name, value)
            return
        raise RuntimeError(f"Undefined variable '{name}'")

    def declare(self, name: str, value: Any):
        self.vars[name] = value


TYPE_MAP = {
    "int":    (int, float),
    "float":  (int, float),
    "string": str,
    "bool":   bool,
    "any":    object,
}


def check_type(value: Any, ann: Optional[TypeAnnotation], name: str):
    if ann is None or ann.name == "any":
        return
    expected = TYPE_MAP.get(ann.name)
    if expected is None:
        return
    if isinstance(expected, tuple):
        ok = isinstance(value, expected)
    else:
        ok = isinstance(value, expected)
    if not ok:
        got = type(value).__name__
        raise RuntimeError(f"Type error: '{name}' expects {ann.name}, got {got}")


class Interpreter:
    def __init__(self, output_fn=None):
        self.global_env = Environment()
        self.output = output_fn or print
        self._setup_builtins()

    def _setup_builtins(self):
        env = self.global_env
        env.declare("math_floor",  lambda args: int(args[0]))
        env.declare("math_ceil",   lambda args: int(args[0]) + (1 if args[0] != int(args[0]) else 0))
        env.declare("math_sqrt",   lambda args: args[0] ** 0.5)
        env.declare("math_abs",    lambda args: abs(args[0]))
        env.declare("math_max",    lambda args: max(args))
        env.declare("math_min",    lambda args: min(args))
        env.declare("math_random", lambda args: __import__('random').random())
        env.declare("tostring",    lambda args: light_repr(args[0]))
        env.declare("tonumber",    lambda args: float(args[0]) if args else 0)
        env.declare("type_of",     lambda args: self._type_of(args[0]))
        env.declare("table_insert",lambda args: self._table_insert(args))
        env.declare("table_remove",lambda args: self._table_remove(args))
        env.declare("string_len",  lambda args: len(str(args[0])))
        env.declare("string_upper",lambda args: str(args[0]).upper())
        env.declare("string_lower",lambda args: str(args[0]).lower())
        env.declare("string_sub",  lambda args: str(args[0])[int(args[1])-1:int(args[2]) if len(args) > 2 else None])
        env.declare("string_find", lambda args: (str(args[0]).find(str(args[1])) + 1) or None)
        env.declare("len",         lambda args: self._len(args[0]))

    def _type_of(self, value):
        if value is None: return "nil"
        if isinstance(value, bool): return "bool"
        if isinstance(value, (int, float)): return "number"
        if isinstance(value, str): return "string"
        if isinstance(value, LightList): return "list"
        if isinstance(value, LightTable): return "table"
        if isinstance(value, LightFunction): return "function"
        if isinstance(value, LightInstance): return value.klass.name
        return "unknown"

    def _len(self, value):
        if isinstance(value, LightList): return len(value.elements)
        if isinstance(value, str): return len(value)
        if isinstance(value, LightTable): return len(value.data)
        raise RuntimeError(f"Cannot get length of {self._type_of(value)}")

    def _table_insert(self, args):
        if not isinstance(args[0], LightList):
            raise RuntimeError("table_insert expects a list as first argument")
        args[0].elements.append(args[1])
        return None

    def _table_remove(self, args):
        if not isinstance(args[0], LightList):
            raise RuntimeError("table_remove expects a list as first argument")
        lst = args[0].elements
        idx = int(args[1]) - 1 if len(args) > 1 else -1
        return lst.pop(idx)

    def execute(self, program: Program):
        env = self.global_env
        for stmt in program.stmts:
            self.exec_stmt(stmt, env)

    def exec_block(self, block: Block, env: Environment):
        for stmt in block.stmts:
            self.exec_stmt(stmt, env)

    def exec_stmt(self, node: Any, env: Environment):
        if isinstance(node, VarDecl):
            value = self.eval_expr(node.value, env) if node.value is not None else None
            check_type(value, node.type_ann, node.name)
            env.declare(node.name, value)

        elif isinstance(node, Assign):
            value = self.eval_expr(node.value, env)
            target = node.target
            if isinstance(target, Ident):
                env.set(target.name, value)
            elif isinstance(target, GetField):
                obj = self.eval_expr(target.obj, env)
                if isinstance(obj, LightInstance):
                    obj.fields[target.field] = value
                elif isinstance(obj, LightTable):
                    obj.data[target.field] = value
                else:
                    raise RuntimeError(f"Cannot set field on {self._type_of(obj)}")
            elif isinstance(target, Index):
                obj = self.eval_expr(target.obj, env)
                key = self.eval_expr(target.key, env)
                if isinstance(obj, LightList):
                    obj.elements[int(key) - 1] = value
                elif isinstance(obj, LightTable):
                    obj.data[key] = value
                else:
                    raise RuntimeError(f"Cannot index {self._type_of(obj)}")
            else:
                raise RuntimeError("Invalid assignment target")

        elif isinstance(node, FnDecl):
            fn = LightFunction(name=node.name, params=node.params, body=node.body,
                               closure=env, return_type=node.return_type)
            env.declare(node.name, fn)

        elif isinstance(node, ClassDecl):
            methods = {}
            for m in node.methods:
                methods[m.name] = LightFunction(name=m.name, params=m.params, body=m.body,
                                                 closure=env, return_type=m.return_type)
            init_fn = None
            if node.init:
                init_fn = LightFunction(name="init", params=node.init.params, body=node.init.body,
                                         closure=env, return_type=None)
            klass = LightClass(name=node.name, fields=node.fields, methods=methods, init=init_fn)
            env.declare(node.name, klass)

        elif isinstance(node, IfStmt):
            for cond, body in node.branches:
                if self._truthy(self.eval_expr(cond, env)):
                    child = Environment(parent=env)
                    self.exec_block(body, child)
                    return
            if node.else_block:
                child = Environment(parent=env)
                self.exec_block(node.else_block, child)

        elif isinstance(node, WhileStmt):
            while self._truthy(self.eval_expr(node.condition, env)):
                child = Environment(parent=env)
                try:
                    self.exec_block(node.body, child)
                except BreakSignal:
                    break
                except ContinueSignal:
                    continue

        elif isinstance(node, ForNumeric):
            start = self.eval_expr(node.start, env)
            stop  = self.eval_expr(node.stop, env)
            step  = self.eval_expr(node.step, env) if node.step else 1
            i = start
            while (step > 0 and i <= stop) or (step < 0 and i >= stop):
                child = Environment(parent=env)
                child.declare(node.var, i)
                try:
                    self.exec_block(node.body, child)
                except BreakSignal:
                    break
                except ContinueSignal:
                    pass
                i += step

        elif isinstance(node, ForIn):
            iterable = self.eval_expr(node.iterable, env)
            items = []
            if isinstance(iterable, LightList):
                items = iterable.elements
            elif isinstance(iterable, str):
                items = list(iterable)
            elif isinstance(iterable, LightTable):
                items = list(iterable.data.values())
            else:
                raise RuntimeError(f"Cannot iterate over {self._type_of(iterable)}")
            for item in items:
                child = Environment(parent=env)
                child.declare(node.var, item)
                try:
                    self.exec_block(node.body, child)
                except BreakSignal:
                    break
                except ContinueSignal:
                    continue

        elif isinstance(node, ReturnStmt):
            value = self.eval_expr(node.value, env) if node.value else None
            raise ReturnSignal(value)

        elif isinstance(node, BreakStmt):
            raise BreakSignal()

        elif isinstance(node, ContinueStmt):
            raise ContinueSignal()

        elif isinstance(node, PrintStmt):
            parts = [light_repr(self.eval_expr(v, env)) for v in node.values]
            self.output("\t".join(parts))

        elif isinstance(node, ExprStmt):
            self.eval_expr(node.expr, env)

        elif isinstance(node, ImportStmt):
            self._handle_import(node, env)

        else:
            raise RuntimeError(f"Unknown statement type: {type(node).__name__}")

    def _handle_import(self, node: ImportStmt, env: Environment):
        alias = node.alias or node.module
        if node.module == "math":
            import math
            t = LightTable({
                "floor": lambda args: int(math.floor(args[0])),
                "ceil":  lambda args: int(math.ceil(args[0])),
                "sqrt":  lambda args: math.sqrt(args[0]),
                "abs":   lambda args: abs(args[0]),
                "max":   lambda args: max(args),
                "min":   lambda args: min(args),
                "pi":    math.pi,
                "huge":  float('inf'),
            })
            env.declare(alias, t)
        elif node.module == "string":
            t = LightTable({
                "len":   lambda args: len(str(args[0])),
                "upper": lambda args: str(args[0]).upper(),
                "lower": lambda args: str(args[0]).lower(),
                "sub":   lambda args: str(args[0])[int(args[1])-1:int(args[2]) if len(args)>2 else None],
                "rep":   lambda args: str(args[0]) * int(args[1]),
                "find":  lambda args: str(args[0]).find(str(args[1])) + 1 or None,
            })
            env.declare(alias, t)
        else:
            raise RuntimeError(f"Unknown module '{node.module}'")

    def eval_expr(self, node: Any, env: Environment) -> Any:
        if isinstance(node, NumberLit):
            return node.value

        if isinstance(node, StringLit):
            return node.value

        if isinstance(node, BoolLit):
            return node.value

        if isinstance(node, NilLit):
            return None

        if isinstance(node, Ident):
            return env.get(node.name)

        if isinstance(node, SelfExpr):
            return env.get("self")

        if isinstance(node, BinOp):
            return self.eval_binop(node, env)

        if isinstance(node, UnOp):
            return self.eval_unop(node, env)

        if isinstance(node, Concat):
            left = self.eval_expr(node.left, env)
            right = self.eval_expr(node.right, env)
            return light_repr(left) + light_repr(right)

        if isinstance(node, LengthOf):
            v = self.eval_expr(node.operand, env)
            return self._len(v)

        if isinstance(node, ListLit):
            elements = [self.eval_expr(e, env) for e in node.elements]
            return LightList(elements)

        if isinstance(node, TableLit):
            data = {}
            auto_idx = 1
            for key, val in node.pairs:
                k = self.eval_expr(key, env) if key else auto_idx
                v = self.eval_expr(val, env)
                data[k] = v
                if key is None:
                    auto_idx += 1
            return LightTable(data)

        if isinstance(node, GetField):
            obj = self.eval_expr(node.obj, env)
            return self._get_field(obj, node.field)

        if isinstance(node, Index):
            obj = self.eval_expr(node.obj, env)
            key = self.eval_expr(node.key, env)
            if isinstance(obj, LightList):
                idx = int(key) - 1
                if idx < 0 or idx >= len(obj.elements):
                    return None
                return obj.elements[idx]
            if isinstance(obj, LightTable):
                return obj.data.get(key)
            if isinstance(obj, str):
                return obj[int(key) - 1]
            raise RuntimeError(f"Cannot index {self._type_of(obj)}")

        if isinstance(node, NewExpr):
            klass = env.get(node.class_name)
            if not isinstance(klass, LightClass):
                raise RuntimeError(f"'{node.class_name}' is not a class")
            instance = LightInstance(klass)
            if klass.init:
                self._call_function(klass.init, node.args, env, instance)
            return instance

        if isinstance(node, Call):
            return self.eval_call(node, env)

        raise RuntimeError(f"Unknown expression type: {type(node).__name__}")

    def _get_field(self, obj: Any, field: str) -> Any:
        if isinstance(obj, LightInstance):
            if field in obj.fields:
                return obj.fields[field]
            if field in obj.klass.methods:
                method = obj.klass.methods[field]
                return BoundMethod(instance=obj, fn=method)
            raise RuntimeError(f"'{obj.klass.name}' has no field or method '{field}'")
        if isinstance(obj, LightTable):
            v = obj.data.get(field)
            return v
        if isinstance(obj, LightClass):
            if field in obj.methods:
                return obj.methods[field]
        raise RuntimeError(f"Cannot access field '{field}' on {self._type_of(obj)}")

    def eval_call(self, node: Call, env: Environment) -> Any:
        callee = self.eval_expr(node.callee, env)

        if callable(callee) and not isinstance(callee, (LightFunction, BoundMethod)):
            args = [self.eval_expr(a, env) for a in node.args]
            return callee(args)

        if isinstance(callee, LightFunction):
            return self._call_function(callee, node.args, env)

        if isinstance(callee, BoundMethod):
            return self._call_function(callee.fn, node.args, env, callee.instance)

        raise RuntimeError(f"'{light_repr(callee)}' is not callable")

    def _call_function(self, fn: LightFunction, arg_nodes: list, caller_env: Environment,
                       instance: Optional[LightInstance] = None) -> Any:
        args = [self.eval_expr(a, caller_env) for a in arg_nodes]
        call_env = Environment(parent=fn.closure)

        if instance:
            call_env.declare("self", instance)

        if len(args) != len(fn.params):
            raise RuntimeError(f"'{fn.name}' expects {len(fn.params)} args, got {len(args)}")

        for param, value in zip(fn.params, args):
            check_type(value, param.type_ann, param.name)
            call_env.declare(param.name, value)

        try:
            self.exec_block(fn.body, call_env)
            return None
        except ReturnSignal as r:
            if fn.return_type:
                check_type(r.value, fn.return_type, f"{fn.name} return value")
            return r.value

    def eval_binop(self, node: BinOp, env: Environment) -> Any:
        op = node.op
        if op == 'and':
            l = self.eval_expr(node.left, env)
            return l if not self._truthy(l) else self.eval_expr(node.right, env)
        if op == 'or':
            l = self.eval_expr(node.left, env)
            return l if self._truthy(l) else self.eval_expr(node.right, env)

        left  = self.eval_expr(node.left, env)
        right = self.eval_expr(node.right, env)

        if op == '+':  return left + right
        if op == '-':  return left - right
        if op == '*':  return left * right
        if op == '/':
            if right == 0: raise RuntimeError("Division by zero")
            return left / right
        if op == '%':  return left % right
        if op == '^':  return left ** right
        if op == '==': return left == right
        if op in ('~=', '!='): return left != right
        if op == '<':  return left < right
        if op == '<=': return left <= right
        if op == '>':  return left > right
        if op == '>=': return left >= right
        raise RuntimeError(f"Unknown operator: {op}")

    def eval_unop(self, node: UnOp, env: Environment) -> Any:
        v = self.eval_expr(node.operand, env)
        if node.op == '-':
            if isinstance(v, (int, float)):
                return -v
            raise RuntimeError(f"Cannot negate {self._type_of(v)}")
        if node.op == 'not':
            return not self._truthy(v)
        raise RuntimeError(f"Unknown unary op: {node.op}")

    def _truthy(self, value: Any) -> bool:
        if value is None or value is False:
            return False
        return True


class BoundMethod:
    def __init__(self, instance: LightInstance, fn: LightFunction):
        self.instance = instance
        self.fn = fn

    def __repr__(self):
        return f"<method {self.fn.name}>"