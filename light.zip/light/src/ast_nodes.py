from dataclasses import dataclass, field
from typing import List, Optional, Any


@dataclass
class Node:
    line: int = field(default=0, init=False, repr=False)


@dataclass
class TypeAnnotation(Node):
    name: str
    nullable: bool = False


@dataclass
class NumberLit(Node):
    value: float


@dataclass
class StringLit(Node):
    value: str


@dataclass
class BoolLit(Node):
    value: bool


@dataclass
class NilLit(Node):
    pass


@dataclass
class Ident(Node):
    name: str


@dataclass
class SelfExpr(Node):
    pass


@dataclass
class BinOp(Node):
    op: str
    left: Any
    right: Any


@dataclass
class UnOp(Node):
    op: str
    operand: Any


@dataclass
class Call(Node):
    callee: Any
    args: List[Any]


@dataclass
class GetField(Node):
    obj: Any
    field: str


@dataclass
class SetField(Node):
    obj: Any
    field: str
    value: Any


@dataclass
class Index(Node):
    obj: Any
    key: Any


@dataclass
class SetIndex(Node):
    obj: Any
    key: Any
    value: Any


@dataclass
class NewExpr(Node):
    class_name: str
    args: List[Any]


@dataclass
class ListLit(Node):
    elements: List[Any]


@dataclass
class TableLit(Node):
    pairs: List[tuple]


@dataclass
class LengthOf(Node):
    operand: Any


@dataclass
class Concat(Node):
    left: Any
    right: Any


@dataclass
class VarDecl(Node):
    name: str
    type_ann: Optional[TypeAnnotation]
    value: Optional[Any]


@dataclass
class Assign(Node):
    target: Any
    value: Any


@dataclass
class Block(Node):
    stmts: List[Any]


@dataclass
class IfStmt(Node):
    branches: List[tuple]
    else_block: Optional[Block]


@dataclass
class WhileStmt(Node):
    condition: Any
    body: Block


@dataclass
class ForNumeric(Node):
    var: str
    start: Any
    stop: Any
    step: Optional[Any]
    body: Block


@dataclass
class ForIn(Node):
    var: str
    iterable: Any
    body: Block


@dataclass
class ReturnStmt(Node):
    value: Optional[Any]


@dataclass
class BreakStmt(Node):
    pass


@dataclass
class ContinueStmt(Node):
    pass


@dataclass
class PrintStmt(Node):
    values: List[Any]


@dataclass
class ExprStmt(Node):
    expr: Any


@dataclass
class ImportStmt(Node):
    module: str
    alias: Optional[str]


@dataclass
class Param(Node):
    name: str
    type_ann: Optional[TypeAnnotation]


@dataclass
class FnDecl(Node):
    name: str
    params: List[Param]
    return_type: Optional[TypeAnnotation]
    body: Block


@dataclass
class FieldDef(Node):
    name: str
    type_ann: Optional[TypeAnnotation]
    default: Optional[Any]


@dataclass
class MethodDef(Node):
    name: str
    params: List[Param]
    return_type: Optional[TypeAnnotation]
    body: Block


@dataclass
class ClassDecl(Node):
    name: str
    fields: List[FieldDef]
    methods: List[MethodDef]
    init: Optional[MethodDef]


@dataclass
class Program(Node):
    stmts: List[Any]