import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from src.lexer import Lexer, LexerError
from src.parser import Parser, ParseError
from src.interpreter import Interpreter


def run_file(path: str):
    if not path.endswith(".light"):
        print(f"Warning: the file '{path}' does not have a .light extension")

    try:
        with open(path, "r", encoding="utf-8") as f:
            source = f.read()
    except FileNotFoundError:
        print(f"Error: File not found: {path}")
        sys.exit(1)

    run_source(source, path)


def run_source(source: str, filename: str = "<stdin>"):
    try:
        lexer = Lexer(source)
        tokens = lexer.tokenize()
    except LexerError as e:
        print(f"Lexical error in '{filename}':\n   {e}")
        sys.exit(1)

    try:
        parser = Parser(tokens)
        ast = parser.parse()
    except ParseError as e:
        print(f"Syntax error in '{filename}':\n   {e}")
        sys.exit(1)

    try:
        interpreter = Interpreter()
        interpreter.execute(ast)
    except RuntimeError as e:
        print(f"Runtime error in '{filename}':\n   {e}")
        sys.exit(1)


def repl():
    print("Light REPL — type 'exit' to quit")
    print("─" * 40)
    history = []
    while True:
        try:
            line = input(">>> ")
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break
        if line.strip() in ("exit", "quit"):
            break
        if not line.strip():
            continue
        history.append(line)
        run_source("\n".join(history), "<repl>")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        repl()
    else:
        run_file(sys.argv[1])