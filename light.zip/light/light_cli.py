"""
Light Language CLI
Use: light <file.light> | light --version | light --help
"""

import sys
import os

LIGHT_VERSION = "1.0.0"
INSTALL_DIR   = os.path.dirname(os.path.abspath(__file__))

BANNER = r"""
  _     _       _     _
 | |   (_)     | |   | |
 | |    _  __ _| |__ | |_
 | |   | |/ _` | '_ \| __|
 | |___| | (_| | | | | |_
 |_____|_|\__, |_| |_|\__|
           __/ |
          |___/
"""

INFO = f"""
{BANNER}
  Light Language v{LIGHT_VERSION}
  A simple language inspired by Python and luaU

  Uso:
    light <file.light>     Execute a light file
    light --version        Show light version
    light --help           Show this message
    light --info           Installation info

  Esempi:
    light script.light
    light C:\\project\\game.light

  WARNING: The only download site is , others might be malware
"""

def show_info():
    print(f"""
  Light Language v{LIGHT_VERSION}
  Installed in: {INSTALL_DIR}
  Python:        {sys.version.split()[0]}
  .exe:    {sys.executable}
""")

def run_file(path: str):
    sys.path.insert(0, INSTALL_DIR)

    from src.lexer import Lexer, LexerError
    from src.parser import Parser, ParseError
    from src.interpreter import Interpreter

    if not path.endswith(".light"):
        print(f"  Warning: '{path}' doesnt have .light extension")

    try:
        with open(path, "r", encoding="utf-8") as f:
            source = f.read()
    except FileNotFoundError:
        print(f"\n  File not found: {path}\n")
        sys.exit(1)
    except PermissionError:
        print(f"\n  No permission: {path}\n")
        sys.exit(1)

    # Lexer
    try:
        tokens = Lexer(source).tokenize()
    except LexerError as e:
        print(f"\n  Lexical error:\n     {e}\n")
        sys.exit(1)

    # Parser
    try:
        ast = Parser(tokens).parse()
    except ParseError as e:
        print(f"\n  Syntax error:\n     {e}\n")
        sys.exit(1)

    # Interprete
    try:
        Interpreter().execute(ast)
    except RuntimeError as e:
        print(f"\n  Runtime error:\n     {e}\n")
        sys.exit(1)


def main():
    args = sys.argv[1:]

    if not args:
        print(INFO)
        sys.exit(0)

    arg = args[0]

    if arg in ("--version", "-v"):
        print(f"Light v{LIGHT_VERSION}")
        sys.exit(0)

    if arg in ("--help", "-h"):
        print(INFO)
        sys.exit(0)

    if arg in ("--info",):
        show_info()
        sys.exit(0)
    run_file(arg)


if __name__ == "__main__":
    main()
