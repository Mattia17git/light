@echo off
chcp 65001 >nul
title Light Language - uninstaller

python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [ERROR] Python not found!
    pause
    exit /b 1
)

python "%~dp0install.py" uninstall

pause
