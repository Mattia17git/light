#!/usr/bin/env python3
"""
mp4_to_lvid.py — convert a video file into a .lvid clip (Light's video
format) plus a .wav audio track, using ffmpeg to do the heavy lifting.

Usage:
    python mp4_to_lvid.py input.mp4 output.lvid [--fps 12] [--width 320]

Requires ffmpeg to be installed and on PATH. Also extracts input's audio
to <output>.wav (next to the .lvid) if the source has an audio track,
so you can play it back separately with audio.loadMusic in Light.
"""
import sys
import os
import subprocess
import shutil
import tempfile
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lvid_encode import encode_lvid

try:
    from PIL import Image
except ImportError:
    print("This script needs Pillow: pip install Pillow", file=sys.stderr)
    sys.exit(1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", help="source video file (mp4, mov, webm, ...)")
    ap.add_argument("output", help="output .lvid path")
    ap.add_argument("--fps", type=float, default=12.0,
                     help="playback fps to sample at (default 12 - keep low, .lvid is uncompressed-ish RLE)")
    ap.add_argument("--width", type=int, default=320,
                     help="resize width in pixels (default 320 - keep small, .lvid isn't a real codec)")
    args = ap.parse_args()

    if shutil.which("ffmpeg") is None:
        print("ffmpeg not found on PATH. Install it first: https://ffmpeg.org/download.html", file=sys.stderr)
        sys.exit(1)

    with tempfile.TemporaryDirectory() as tmp:
        frame_pattern = os.path.join(tmp, "frame_%05d.png")

        print("extracting frames...")
        subprocess.run([
            "ffmpeg", "-y", "-i", args.input,
            "-vf", f"fps={args.fps},scale={args.width}:-2",
            frame_pattern
        ], check=True, capture_output=True)

        frame_files = sorted(f for f in os.listdir(tmp) if f.endswith(".png"))
        if not frame_files:
            print("no frames extracted - check the input file", file=sys.stderr)
            sys.exit(1)

        print(f"loading {len(frame_files)} frames...")
        frames = [Image.open(os.path.join(tmp, f)).convert("RGB") for f in frame_files]

        encode_lvid(frames, args.fps, args.output)

        audio_out = os.path.splitext(args.output)[0] + ".wav"
        print("extracting audio (if any)...")
        result = subprocess.run([
            "ffmpeg", "-y", "-i", args.input,
            "-vn", "-ar", "44100", "-ac", "1", audio_out
        ], capture_output=True)

        if result.returncode == 0 and os.path.exists(audio_out):
            print(f"wrote {audio_out}")
        else:
            print("no audio track found (or extraction failed) - skipping .wav")
            if os.path.exists(audio_out):
                os.remove(audio_out)


if __name__ == "__main__":
    main()
