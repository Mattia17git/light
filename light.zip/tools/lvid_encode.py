import struct


def rle_encode(raw_bytes):
    out = bytearray()
    n = len(raw_bytes)
    assert n % 3 == 0
    i = 0
    while i < n:
        r, g, b = raw_bytes[i], raw_bytes[i + 1], raw_bytes[i + 2]
        run = 1
        while (i + run * 3 < n and run < 255
               and raw_bytes[i + run * 3] == r
               and raw_bytes[i + run * 3 + 1] == g
               and raw_bytes[i + run * 3 + 2] == b):
            run += 1
        out.append(run)
        out.append(r)
        out.append(g)
        out.append(b)
        i += run * 3
    return bytes(out)


def encode_lvid(frames, fps, out_path):
    """
    frames: list of objects with .tobytes() returning RGB24 raw bytes
            (e.g. PIL Image opened/converted to 'RGB'), all the same
            width/height.
    fps: playback frame rate
    out_path: output .lvid file path
    """
    if not frames:
        raise ValueError("no frames given")

    width, height = frames[0].size
    compressed = []
    for f in frames:
        if f.size != (width, height):
            f = f.resize((width, height))
        raw = f.convert("RGB").tobytes()
        compressed.append(rle_encode(raw))

    with open(out_path, "wb") as out:
        out.write(b"LVID")
        out.write(struct.pack("<III", width, height, len(frames)))
        out.write(struct.pack("<f", fps))
        for c in compressed:
            out.write(struct.pack("<I", len(c)))
        for c in compressed:
            out.write(c)

    total = sum(len(c) for c in compressed)
    print(f"wrote {out_path}: {len(frames)} frames, {width}x{height} @ {fps}fps, {total/1024:.1f} KB")
